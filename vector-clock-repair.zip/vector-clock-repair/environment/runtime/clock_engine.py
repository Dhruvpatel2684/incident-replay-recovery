"""
Clock Engine - Main entrypoint for distributed event log processing.

Reads an event log, processes events through the vector clock state machine,
performs causal analysis, and writes output files.

Output files:
- /app/runtime/causal_state.jsonl: Per-event vector clock state
- /app/runtime/causal_report.json: Causal analysis summary with fingerprint
"""

import os
import sys

# Ensure runtime directory is in path
runtime_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, runtime_dir)

from event_parser import parse_event_log, get_process_ids
from vector_clock import VectorClockEngine
from causal_analyzer import CausalAnalyzer
from report_writer import write_causal_state, write_causal_report


def main():
    """Main processing pipeline."""
    # Locate input file
    event_log_path = os.path.join(runtime_dir, "event_log.txt")

    if not os.path.exists(event_log_path):
        print(f"ERROR: Event log not found at {event_log_path}", file=sys.stderr)
        sys.exit(1)

    print(f"[clock_engine] Loading event log from {event_log_path}")

    # Step 1: Parse events
    events = parse_event_log(event_log_path)
    process_ids = get_process_ids(events)
    print(f"[clock_engine] Parsed {len(events)} events across {len(process_ids)} processes")

    # Step 2: Process through vector clock engine
    engine = VectorClockEngine(process_ids)
    event_clocks = engine.process_all(events)
    print(f"[clock_engine] Vector clocks computed for all events")

    # Step 3: Causal analysis
    analyzer = CausalAnalyzer(event_clocks)
    analyzer.analyze()
    print(f"[clock_engine] Causal analysis complete: "
          f"{analyzer.get_happens_before_count()} HB pairs, "
          f"{analyzer.get_concurrent_count()} concurrent pairs")

    # Step 4: Write outputs
    state_path = os.path.join(runtime_dir, "causal_state.jsonl")
    report_path = os.path.join(runtime_dir, "causal_report.json")

    write_causal_state(event_clocks, state_path)
    write_causal_report(analyzer, event_clocks, process_ids, report_path)

    print(f"[clock_engine] Output written to:")
    print(f"  - {state_path}")
    print(f"  - {report_path}")
    print(f"[clock_engine] Done.")


if __name__ == "__main__":
    main()
