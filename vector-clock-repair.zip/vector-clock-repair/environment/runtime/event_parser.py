"""
Event log parser for distributed system traces.

Parses the structured event log format and produces typed event records
for downstream processing by the vector clock state machine.
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional, Dict


@dataclass
class Event:
    """Represents a single event in a distributed system trace."""
    timestamp: int
    process: str
    event_type: str  # LOCAL, SEND, RECEIVE
    payload: Dict[str, str] = field(default_factory=dict)
    sender_clock: Optional[Dict[str, int]] = None
    msg_id: Optional[str] = None
    target: Optional[str] = None  # For SEND: destination process
    source: Optional[str] = None  # For RECEIVE: source process


def parse_payload(raw_payload: str) -> Dict[str, str]:
    """Parse a comma-separated key=value payload string into a dictionary.
    
    Handles the special case where sender_clock contains colons and commas
    by treating everything after 'sender_clock=' as the clock string.
    """
    result = {}
    sc_marker = "sender_clock="
    sc_idx = raw_payload.find(sc_marker)

    if sc_idx >= 0:
        # Split into pre-clock and clock portions
        pre_clock = raw_payload[:sc_idx].rstrip(",")
        clock_str = raw_payload[sc_idx + len(sc_marker):]

        # Parse pre-clock key=value pairs
        for part in pre_clock.split(","):
            part = part.strip()
            if "=" in part:
                k, v = part.split("=", 1)
                result[k] = v

        # Store raw clock string for later parsing
        result["sender_clock"] = clock_str
    else:
        # Simple key=value parsing
        for part in raw_payload.split(","):
            part = part.strip()
            if "=" in part:
                k, v = part.split("=", 1)
                result[k] = v

    return result


def parse_sender_clock(clock_str: str) -> Dict[str, int]:
    """Parse a vector clock string like 'P1:3,P2:1,P3:0' into a dict."""
    clock = {}
    for component in clock_str.split(","):
        component = component.strip()
        if ":" in component:
            proc, val = component.split(":", 1)
            clock[proc] = int(val)
    return clock


def parse_event_log(filepath: str) -> List[Event]:
    """Parse an event log file and return a list of Event objects.
    
    Events are returned in file order (which should be sorted by timestamp
    for well-formed logs, but the parser does not enforce this).
    """
    events = []

    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Event log not found: {filepath}")

    with open(filepath, "r") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            parts = line.split("|")
            if len(parts) != 4:
                raise ValueError(
                    f"Malformed event at line {line_num}: expected 4 pipe-delimited fields, "
                    f"got {len(parts)}"
                )

            timestamp_str, process, event_type, raw_payload = parts

            # Validate timestamp
            try:
                timestamp = int(timestamp_str)
            except ValueError:
                raise ValueError(
                    f"Invalid timestamp at line {line_num}: '{timestamp_str}'"
                )

            # Validate event type
            if event_type not in ("LOCAL", "SEND", "RECEIVE"):
                raise ValueError(
                    f"Unknown event type at line {line_num}: '{event_type}'"
                )

            # Parse payload
            payload = parse_payload(raw_payload)

            # Build event record
            event = Event(
                timestamp=timestamp,
                process=process,
                event_type=event_type,
                payload=payload,
            )

            # Extract message metadata for SEND/RECEIVE
            if event_type == "SEND":
                event.target = payload.get("to")
                event.msg_id = payload.get("msg_id")
            elif event_type == "RECEIVE":
                event.source = payload.get("from")
                event.msg_id = payload.get("msg_id")
                if "sender_clock" in payload:
                    event.sender_clock = parse_sender_clock(payload["sender_clock"])

            events.append(event)

    # Sort by timestamp for deterministic processing order
    events.sort(key=lambda e: (e.timestamp, e.process))

    return events


def get_process_ids(events: List[Event]) -> List[str]:
    """Extract unique process IDs from event list, sorted."""
    return sorted(set(e.process for e in events))
