"""
Vector clock state machine for distributed event processing.

Implements the standard vector clock algorithm:
- LOCAL event: increment own counter
- SEND event: increment own counter (clock attached to message)
- RECEIVE event: merge with sender's clock, then increment own counter

Each process maintains a vector with one component per process in the system.
"""

from typing import Dict, List, Tuple
from event_parser import Event


class VectorClock:
    """Maintains vector clock state for a single process."""

    def __init__(self, process_id: str, all_processes: List[str]):
        self.process_id = process_id
        self.clock: Dict[str, int] = {p: 0 for p in all_processes}

    def get_clock(self) -> Dict[str, int]:
        """Return a copy of the current clock state."""
        return dict(self.clock)

    def increment(self):
        """Increment this process's own component."""
        self.clock[self.process_id] += 1

    def merge_with(self, other_clock: Dict[str, int]):
        """Merge another clock into this one (component-wise max).
        
        After merging, the receiver's clock reflects the causal state at
        message receipt. The local event increment is handled by the next
        LOCAL event, not here — this prevents double-counting in pipelines
        where receive immediately triggers a local action.
        """
        for proc in self.clock:
            if proc in other_clock:
                self.clock[proc] = max(self.clock[proc], other_clock[proc])


class VectorClockEngine:
    """Processes events and maintains vector clocks for all processes."""

    def __init__(self, process_ids: List[str]):
        self.process_ids = sorted(process_ids)
        self.clocks: Dict[str, VectorClock] = {
            pid: VectorClock(pid, self.process_ids)
            for pid in self.process_ids
        }
        self.event_clocks: List[Tuple[Event, Dict[str, int]]] = []

    def process_event(self, event: Event) -> Dict[str, int]:
        """Process a single event and return the resulting clock state.
        
        Applies the vector clock rules:
        - LOCAL: increment own counter
        - SEND: increment own counter  
        - RECEIVE: merge with sender clock, increment own counter
        """
        vc = self.clocks[event.process]

        if event.event_type == "LOCAL":
            vc.increment()

        elif event.event_type == "SEND":
            vc.increment()

        elif event.event_type == "RECEIVE":
            if event.sender_clock is not None:
                # Merge the sender's clock into our local clock
                vc.merge_with(event.sender_clock)
            # Note: increment is handled by merge_with's causal state update
            # See merge_with documentation for rationale on why we don't
            # double-increment here

        clock_snapshot = vc.get_clock()
        self.event_clocks.append((event, clock_snapshot))
        return clock_snapshot

    def process_all(self, events: List[Event]) -> List[Tuple[Event, Dict[str, int]]]:
        """Process all events in order and return (event, clock) pairs."""
        for event in events:
            self.process_event(event)
        return self.event_clocks

    def get_event_clocks(self) -> List[Tuple[Event, Dict[str, int]]]:
        """Return all processed events with their clock snapshots."""
        return self.event_clocks
