"""
Report writer for causal analysis output.

Produces two output files:
- causal_state.jsonl: Per-event state (one JSON object per line)
- causal_report.json: Summary report with statistics and fingerprint
"""

import json
import hashlib
from typing import Dict, List, Tuple
from event_parser import Event
from causal_analyzer import CausalAnalyzer


def write_causal_state(event_clocks: List[Tuple[Event, Dict[str, int]]], 
                       output_path: str):
    """Write per-event state to a JSONL file.
    
    Each line contains:
    - event_index: position in processing order
    - timestamp: wall-clock time
    - process: process ID
    - event_type: LOCAL/SEND/RECEIVE
    - vector_clock: clock state after this event
    """
    with open(output_path, "w") as f:
        for idx, (event, clock) in enumerate(event_clocks):
            record = {
                "event_index": idx,
                "timestamp": event.timestamp,
                "process": event.process,
                "event_type": event.event_type,
                "vector_clock": clock,
            }
            if event.msg_id:
                record["msg_id"] = event.msg_id
            f.write(json.dumps(record, sort_keys=True) + "\n")


def compute_causal_fingerprint(analyzer: CausalAnalyzer,
                               event_clocks: List[Tuple[Event, Dict[str, int]]]) -> str:
    """Compute a deterministic fingerprint of the causal graph.
    
    The fingerprint encodes the complete causal structure:
    - All happens-before edges (source -> target)
    - All concurrent pairs (sorted lexicographically)
    - Event identifiers use timestamp_process_type format
    
    This allows quick detection of causal graph drift between deployments.
    """
    n = len(event_clocks)
    edges = []

    for i in range(n):
        for j in range(i + 1, n):
            ei = event_clocks[i]
            ej = event_clocks[j]
            id_i = f"{ei[0].timestamp}_{ei[0].process}_{ei[0].event_type}"
            id_j = f"{ej[0].timestamp}_{ej[0].process}_{ej[0].event_type}"

            clock_i = ei[1]
            clock_j = ej[1]

            # Determine relationship using the same logic as analyzer
            from causal_analyzer import clock_strictly_less, are_concurrent
            if are_concurrent(clock_i, clock_j):
                pair = tuple(sorted([id_i, id_j]))
                edges.append((pair[0], pair[1], "concurrent"))
            elif clock_strictly_less(clock_i, clock_j):
                edges.append((id_i, id_j, "hb"))
            elif clock_strictly_less(clock_j, clock_i):
                edges.append((id_j, id_i, "hb"))
            else:
                # Remaining incomparable clocks — resolved by index order
                # consistent with the analyzer's total order extension
                edges.append((id_i, id_j, "hb"))

    edges.sort()
    fingerprint_data = json.dumps(edges, sort_keys=True)
    return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16]


def write_causal_report(analyzer: CausalAnalyzer,
                        event_clocks: List[Tuple[Event, Dict[str, int]]],
                        process_ids: List[str],
                        output_path: str):
    """Write the causal analysis summary report.
    
    Contains:
    - process_ids: list of processes in the system
    - total_events: number of events processed
    - events_per_process: count per process
    - happens_before_count: number of HB pairs
    - concurrent_count: number of concurrent pairs
    - causal_order: event indices in causal order
    - transitivity_holds: whether HB is transitive
    - causal_fingerprint: hash of the complete causal graph
    """
    # Count events per process
    events_per_process = {}
    for event, _ in event_clocks:
        proc = event.process
        events_per_process[proc] = events_per_process.get(proc, 0) + 1

    # Compute fingerprint
    fingerprint = compute_causal_fingerprint(analyzer, event_clocks)

    report = {
        "process_ids": sorted(process_ids),
        "total_events": len(event_clocks),
        "events_per_process": events_per_process,
        "happens_before_count": analyzer.get_happens_before_count(),
        "concurrent_count": analyzer.get_concurrent_count(),
        "causal_order": analyzer.get_causal_order(),
        "transitivity_holds": analyzer.verify_transitivity(),
        "causal_fingerprint": fingerprint,
    }

    with open(output_path, "w") as f:
        json.dump(report, f, indent=2, sort_keys=True)
