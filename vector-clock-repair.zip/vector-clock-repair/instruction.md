# Vector Clock Causal Ordering — Incident Report

## Context

We have a distributed event log replayer that reconstructs causal ordering from vector clocks. It processes event logs from a 3-process system and produces a causal analysis report. This has been running in prod for months, but after a recent refactor the outputs started drifting.

## Symptoms

Our formal verification tool (TLA+ model checker) produces a reference causal graph for the same event log. When we compare:

1. **Causal chains seem too short** — The happens-before relationship count is lower than expected. Events that should be causally linked (because one received a message from another) appear to have weaker clock values than they should.

2. **Concurrent event detection is way off** — We expect dozens of concurrent pairs (events on different processes with no message path between them), but the system reports almost none. It's like it thinks nearly everything is causally ordered.

3. **The ordering doesn't match what our formal verification tool produces** — The "causal order" in the report appears to just be timestamp-sorted, which... isn't how causality works in distributed systems. Physical time ≠ logical time.

4. **Fingerprint drifts between deploys** — The causal fingerprint (SHA-256 of the graph structure) doesn't match the reference. This blocks our CI pipeline because we use the fingerprint for regression detection.

## System Architecture

The pipeline is:

```
event_log.txt → event_parser.py → vector_clock.py → causal_analyzer.py → report_writer.py
                                                                              ↓
                                                              causal_state.jsonl + causal_report.json
```

- `clock_engine.py` — Orchestrator. Reads the log, runs the pipeline, writes output. This file is fine.
- `event_parser.py` — Parses the pipe-delimited log format. This file is fine.
- `vector_clock.py` — Maintains per-process vector clocks. Handles LOCAL/SEND/RECEIVE semantics.
- `causal_analyzer.py` — Classifies all event pairs as happens-before or concurrent. Computes causal ordering.
- `report_writer.py` — Writes the JSONL state file and JSON report with fingerprint.

## Input Format

The event log (`event_log.txt`) uses pipe-delimited fields:

```
TIMESTAMP|PROCESS|EVENT_TYPE|PAYLOAD
```

- TIMESTAMP: wall-clock milliseconds (monotonic per process, NOT globally synchronized)
- PROCESS: P1, P2, or P3
- EVENT_TYPE: LOCAL, SEND, or RECEIVE
- PAYLOAD: key=value pairs. RECEIVE events include `sender_clock=P1:X,P2:Y,P3:Z`

## Output Schema

### causal_state.jsonl

One JSON object per line, one per event:
```json
{"event_index": 0, "timestamp": 100, "process": "P1", "event_type": "LOCAL", "vector_clock": {"P1": 1, "P2": 0, "P3": 0}}
```

### causal_report.json

```json
{
  "process_ids": ["P1", "P2", "P3"],
  "total_events": 32,
  "events_per_process": {"P1": 12, "P2": 11, "P3": 9},
  "happens_before_count": <int>,
  "concurrent_count": <int>,
  "causal_order": [<event indices in causal order>],
  "transitivity_holds": <bool>,
  "causal_fingerprint": "<16-char hex string>"
}
```

## Environment

- Python 3.11 available system-wide
- No external dependencies needed (stdlib only)
- Output files go in `/app/runtime/`
- Run with: `python3 /app/runtime/clock_engine.py`

## What We Need

Find and fix the bugs causing the symptoms above. The event log and parser are correct — the issues are in how clocks are maintained, how causal relationships are determined, and how the report is generated.

Don't add dependencies. Don't change the input format or output schema. Just make the numbers right.
