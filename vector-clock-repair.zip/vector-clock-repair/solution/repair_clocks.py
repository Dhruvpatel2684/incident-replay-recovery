"""
Oracle solution for vector-clock-repair task.

Fixes the 4 bugs:
1. vector_clock.py: RECEIVE must increment own counter AFTER merge
2. causal_analyzer.py: Causal ordering uses topological sort of happens-before, not timestamps
3. causal_analyzer.py: Concurrent means NEITHER clock dominates (not BOTH dominate)
4. report_writer.py: Fingerprint uses the same fixed logic from bugs 2+3

This script re-processes the event log with correct logic and overwrites the output files.
"""

import os
import sys
import json
import hashlib

# Ensure runtime directory is in path
runtime_dir = "/app/runtime"
sys.path.insert(0, runtime_dir)

from event_parser import parse_event_log, get_process_ids, Event
from typing import Dict, List, Tuple, Set


# ============================================================
# Fixed Vector Clock (Bug 1 fix: increment after merge)
# ============================================================

class FixedVectorClock:
    """Vector clock that correctly increments on receive."""
    
    def __init__(self, process_id: str, all_processes: List[str]):
        self.process_id = process_id
        self.clock: Dict[str, int] = {p: 0 for p in all_processes}
    
    def get_clock(self) -> Dict[str, int]:
        return dict(self.clock)
    
    def increment(self):
        self.clock[self.process_id] += 1
    
    def merge_and_increment(self, other_clock: Dict[str, int]):
        """Correct receive behavior: merge then increment own counter."""
        for proc in self.clock:
            if proc in other_clock:
                self.clock[proc] = max(self.clock[proc], other_clock[proc])
        # FIX: Always increment own counter after merge on receive
        self.clock[self.process_id] += 1


def process_events_fixed(events: List[Event], process_ids: List[str]) -> List[Tuple[Event, Dict[str, int]]]:
    """Process all events with correct vector clock logic."""
    clocks = {pid: FixedVectorClock(pid, sorted(process_ids)) for pid in process_ids}
    event_clocks = []
    
    for event in events:
        vc = clocks[event.process]
        
        if event.event_type == "LOCAL":
            vc.increment()
        elif event.event_type == "SEND":
            vc.increment()
        elif event.event_type == "RECEIVE":
            if event.sender_clock is not None:
                # FIX: merge AND increment (not just merge)
                vc.merge_and_increment(event.sender_clock)
        
        event_clocks.append((event, vc.get_clock()))
    
    return event_clocks


# ============================================================
# Fixed Causal Analysis (Bug 2 + Bug 3 fixes)
# ============================================================

def clock_leq(clock_a: Dict[str, int], clock_b: Dict[str, int]) -> bool:
    """Check if clock_a <= clock_b."""
    return all(clock_a.get(k, 0) <= clock_b.get(k, 0) for k in clock_a)


def clock_strictly_less(clock_a: Dict[str, int], clock_b: Dict[str, int]) -> bool:
    """Check if clock_a < clock_b (happens-before)."""
    all_leq = all(clock_a.get(k, 0) <= clock_b.get(k, 0) for k in clock_a)
    some_lt = any(clock_a.get(k, 0) < clock_b.get(k, 0) for k in clock_a)
    return all_leq and some_lt


def are_concurrent_fixed(clock_a: Dict[str, int], clock_b: Dict[str, int]) -> bool:
    """FIX Bug 3: Concurrent means NEITHER dominates the other.
    
    Two events are concurrent iff:
    - NOT (clock_a < clock_b)  -- a does not happen-before b
    - NOT (clock_b < clock_a)  -- b does not happen-before a
    """
    return not clock_strictly_less(clock_a, clock_b) and not clock_strictly_less(clock_b, clock_a)


def analyze_causality_fixed(event_clocks: List[Tuple[Event, Dict[str, int]]]):
    """Perform correct causal analysis."""
    n = len(event_clocks)
    happens_before_pairs = []
    concurrent_pairs = []
    
    for i in range(n):
        for j in range(i + 1, n):
            clock_i = event_clocks[i][1]
            clock_j = event_clocks[j][1]
            
            if clock_strictly_less(clock_i, clock_j):
                happens_before_pairs.append((i, j))
            elif clock_strictly_less(clock_j, clock_i):
                happens_before_pairs.append((j, i))
            else:
                # FIX Bug 3: neither dominates = concurrent
                concurrent_pairs.append((i, j))
    
    # FIX Bug 2: Topological sort based on happens-before, not timestamps
    causal_order = compute_topological_order(event_clocks, happens_before_pairs)
    
    return happens_before_pairs, concurrent_pairs, causal_order


def compute_topological_order(event_clocks, hb_pairs) -> List[int]:
    """FIX Bug 2: Compute causal ordering via topological sort of happens-before DAG.
    
    Uses Kahn's algorithm with process-ID tiebreaking for determinism.
    """
    n = len(event_clocks)
    in_degree = [0] * n
    adj = [[] for _ in range(n)]
    
    for src, dst in hb_pairs:
        adj[src].append(dst)
        in_degree[dst] += 1
    
    # Start with nodes having no incoming edges
    # Use (process_id, timestamp, index) for deterministic tiebreaking
    import heapq
    queue = []
    for i in range(n):
        if in_degree[i] == 0:
            e = event_clocks[i][0]
            heapq.heappush(queue, (e.process, e.timestamp, i))
    
    order = []
    while queue:
        _, _, node = heapq.heappop(queue)
        order.append(node)
        for nxt in adj[node]:
            in_degree[nxt] -= 1
            if in_degree[nxt] == 0:
                e = event_clocks[nxt][0]
                heapq.heappush(queue, (e.process, e.timestamp, nxt))
    
    return order


def verify_transitivity_fixed(hb_pairs, n) -> bool:
    """Verify transitivity of happens-before relation."""
    hb_set = set(hb_pairs)
    # Build reachability
    for i in range(n):
        for j in range(n):
            if (i, j) in hb_set:
                for k in range(n):
                    if (j, k) in hb_set:
                        if (i, k) not in hb_set:
                            return False
    return True


# ============================================================
# Fixed Fingerprint (Bug 4 fix: uses corrected concurrent detection)
# ============================================================

def compute_fingerprint_fixed(event_clocks: List[Tuple[Event, Dict[str, int]]]) -> str:
    """Compute fingerprint with correct causal logic."""
    n = len(event_clocks)
    edges = []
    
    for i in range(n):
        for j in range(i + 1, n):
            ei = event_clocks[i]
            ej = event_clocks[j]
            id_i = f"{ei[0].timestamp}_{ei[0].process}_{ei[0].event_type}"
            id_j = f"{ej[0].timestamp}_{ej[0].process}_{ej[0].event_type}"
            
            clock_i = ei[1]
            clock_j = ej[1]
            
            # FIX: use correct concurrent detection
            if are_concurrent_fixed(clock_i, clock_j):
                pair = tuple(sorted([id_i, id_j]))
                edges.append((pair[0], pair[1], "concurrent"))
            elif clock_strictly_less(clock_i, clock_j):
                edges.append((id_i, id_j, "hb"))
            elif clock_strictly_less(clock_j, clock_i):
                edges.append((id_j, id_i, "hb"))
            else:
                pair = tuple(sorted([id_i, id_j]))
                edges.append((pair[0], pair[1], "concurrent"))
    
    edges.sort()
    fingerprint_data = json.dumps(edges, sort_keys=True)
    return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16]


# ============================================================
# Main
# ============================================================

def main():
    event_log_path = os.path.join(runtime_dir, "event_log.txt")
    
    # Parse events
    events = parse_event_log(event_log_path)
    process_ids = get_process_ids(events)
    
    # Process with fixed vector clocks
    event_clocks = process_events_fixed(events, process_ids)
    
    # Analyze with fixed causal logic
    hb_pairs, conc_pairs, causal_order = analyze_causality_fixed(event_clocks)
    
    # Verify transitivity
    transitivity = verify_transitivity_fixed(hb_pairs, len(event_clocks))
    
    # Compute fixed fingerprint
    fingerprint = compute_fingerprint_fixed(event_clocks)
    
    # Write causal_state.jsonl
    state_path = os.path.join(runtime_dir, "causal_state.jsonl")
    with open(state_path, "w") as f:
        for idx, (event, clock) in enumerate(event_clocks):
            record = {
                "event_index": idx,
                "timestamp": event.timestamp,
                "process": event.process,
                "event_type": event.event_type,
                "vector_clock": clock,
            }
            if event.msg_id:
                record["msg_id"] = event.msg_id
            f.write(json.dumps(record, sort_keys=True) + "\n")
    
    # Write causal_report.json
    events_per_process = {}
    for event, _ in event_clocks:
        proc = event.process
        events_per_process[proc] = events_per_process.get(proc, 0) + 1
    
    report = {
        "process_ids": sorted(process_ids),
        "total_events": len(event_clocks),
        "events_per_process": events_per_process,
        "happens_before_count": len(hb_pairs),
        "concurrent_count": len(conc_pairs),
        "causal_order": causal_order,
        "transitivity_holds": transitivity,
        "causal_fingerprint": fingerprint,
    }
    
    report_path = os.path.join(runtime_dir, "causal_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2, sort_keys=True)
    
    print(f"[repair] Fixed processing complete:")
    print(f"  HB pairs: {len(hb_pairs)}")
    print(f"  Concurrent pairs: {len(conc_pairs)}")
    print(f"  Fingerprint: {fingerprint}")


if __name__ == "__main__":
    main()
