"""
Test suite for vector clock causal ordering system.

14 tests in 4 tiers:
- Tier 1 (6 tests): Structural checks - pass with buggy code
- Tier 2 (3 tests): Clock value checks - need Bug 1 fixed
- Tier 3 (3 tests): Ordering/concurrency checks - need Bugs 2+3 fixed
- Tier 4 (2 tests): Full consistency checks - need all bugs fixed
"""

import json
import os
import hashlib

# Output file paths
RUNTIME_DIR = "/app/runtime"
STATE_PATH = os.path.join(RUNTIME_DIR, "causal_state.jsonl")
REPORT_PATH = os.path.join(RUNTIME_DIR, "causal_report.json")


def load_state():
    """Load causal_state.jsonl as a list of dicts."""
    records = []
    with open(STATE_PATH, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def load_report():
    """Load causal_report.json."""
    with open(REPORT_PATH, "r") as f:
        return json.load(f)


# =============================================================================
# TIER 1: Structural tests (pass with buggy code)
# =============================================================================

class TestTier1Structural:
    """Basic structural checks that pass even with buggy clock logic."""

    def test_output_files_exist(self):
        """Both output files must exist after processing."""
        assert os.path.exists(STATE_PATH), f"Missing: {STATE_PATH}"
        assert os.path.exists(REPORT_PATH), f"Missing: {REPORT_PATH}"

    def test_three_processes_in_output(self):
        """Report must identify exactly 3 processes."""
        report = load_report()
        assert len(report["process_ids"]) == 3

    def test_process_ids_correct(self):
        """Process IDs must be P1, P2, P3."""
        report = load_report()
        assert report["process_ids"] == ["P1", "P2", "P3"]

    def test_event_count_per_process(self):
        """Each process must have the correct event count."""
        report = load_report()
        epp = report["events_per_process"]
        assert epp["P1"] == 12, f"P1 expected 12, got {epp['P1']}"
        assert epp["P2"] == 11, f"P2 expected 11, got {epp['P2']}"
        assert epp["P3"] == 9, f"P3 expected 9, got {epp['P3']}"

    def test_report_has_required_fields(self):
        """Report must contain all required fields."""
        report = load_report()
        required = [
            "process_ids", "total_events", "events_per_process",
            "happens_before_count", "concurrent_count", "causal_order",
            "transitivity_holds", "causal_fingerprint"
        ]
        for field in required:
            assert field in report, f"Missing field: {field}"

    def test_total_events_count(self):
        """Total event count must be 32."""
        report = load_report()
        assert report["total_events"] == 32
        state = load_state()
        assert len(state) == 32


# =============================================================================
# TIER 2: Clock value tests (need Bug 1 fixed - merge must increment)
# =============================================================================

class TestTier2ClockValues:
    """Tests that verify correct vector clock computation on receive."""

    def test_vector_clock_after_receive(self):
        """After P2 receives m01, its own counter must be incremented.
        
        P2 starts with clock [P1:0, P2:1, P3:0] (after its LOCAL init).
        P2 receives m01 with sender_clock [P1:3, P2:0, P3:0].
        Correct merge: max([0,1,0], [3,0,0]) = [3,1,0], then +1 on P2 = [3,2,0].
        
        If the receive increment is missing, P2 would be [3,1,0] instead.
        """
        state = load_state()
        # Find P2's RECEIVE event for m01 (timestamp 300)
        recv_event = None
        for record in state:
            if (record["process"] == "P2" and 
                record["event_type"] == "RECEIVE" and
                record["timestamp"] == 300):
                recv_event = record
                break
        
        assert recv_event is not None, "Could not find P2 RECEIVE event at ts=300"
        clock = recv_event["vector_clock"]
        assert clock["P2"] == 2, (
            f"After receive+merge, P2's own counter should be 2 (merge then increment). "
            f"Got P2={clock['P2']}. If P2=1, the post-merge increment is missing."
        )
        assert clock["P1"] == 3, f"P2 should have P1=3 after merge. Got {clock['P1']}"
        assert clock["P3"] == 0, f"P2 should have P3=0 after merge. Got {clock['P3']}"

    def test_clock_dominance(self):
        """After receive, the receiver's clock must strictly dominate the sender's clock.
        
        P1 receives m03 at ts=500. Sender clock is [P1:3, P2:4, P3:6].
        P1's clock before this receive is [P1:3, P2:0, P3:0] (last event was SEND at ts=250).
        
        Correct: merge gives [3,4,6], then increment P1 -> [4,4,6]. 
        This strictly dominates [3,4,6] because P1:4 > 3.
        
        If increment is missing: merge gives [3,4,6] which EQUALS sender clock.
        Equal does NOT satisfy strict dominance (all >= but not any >).
        """
        state = load_state()
        
        # Check P1's receive of m03 (ts=500, sender_clock=P1:3,P2:4,P3:6)
        recv_event = None
        for record in state:
            if (record["process"] == "P1" and 
                record["event_type"] == "RECEIVE" and
                record["timestamp"] == 500):
                recv_event = record
                break
        
        assert recv_event is not None, "Could not find P1 RECEIVE event at ts=500"
        clock = recv_event["vector_clock"]
        sender_clock = {"P1": 3, "P2": 4, "P3": 6}
        
        # Receiver must dominate: all >= AND at least one >
        for proc in sender_clock:
            assert clock[proc] >= sender_clock[proc], (
                f"Receiver clock must be >= sender for all components. "
                f"{proc}: receiver={clock[proc]} < sender={sender_clock[proc]}"
            )
        
        assert any(clock[p] > sender_clock[p] for p in sender_clock), (
            f"Receiver clock must strictly dominate sender clock (at least one component >). "
            f"Got receiver={clock}, sender={sender_clock}. "
            f"If they're equal, the post-merge increment on the receiver's own component is missing."
        )

    def test_causal_chain_length(self):
        """Vector clock values cascade: P1's final own-component must be 12.
        
        P1 has 12 events total (5 LOCAL + 3 SEND + 4 RECEIVE).
        Each event type increments P1's own counter exactly once:
        - LOCAL: increment
        - SEND: increment
        - RECEIVE: merge then increment
        
        So P1's final own-component = 12.
        If receive doesn't increment, P1's counter only advances on
        LOCAL and SEND: 5 + 3 = 8 base, plus merges that happen to
        advance P1 (from sender clocks with higher P1 values), giving 11.
        """
        state = load_state()
        # Find P1's last event (ts=920, SEND)
        p1_last = None
        for record in reversed(state):
            if record["process"] == "P1":
                p1_last = record
                break
        
        assert p1_last is not None, "Could not find any P1 events in state"
        assert p1_last["vector_clock"]["P1"] == 12, (
            f"P1's final own-component should be 12 (one increment per event). "
            f"Got {p1_last['vector_clock']['P1']}. If less than 12, receive events "
            f"are not incrementing the process's own counter."
        )


# =============================================================================
# TIER 3: Ordering and concurrency tests (need Bugs 2+3 fixed)
# =============================================================================

class TestTier3CausalOrdering:
    """Tests that verify correct causal ordering and concurrent detection."""

    def test_causal_ordering_not_timestamp_based(self):
        """The causal order must NOT be a simple timestamp sort.
        
        A correct causal ordering is a topological sort of the happens-before
        DAG. Since concurrent events can be ordered freely, the correct
        topological sort (using process-ID tiebreaking) differs from 
        pure timestamp ordering.
        
        The timestamp-sorted order would be [0,1,2,3,...,31] since events
        are indexed by ascending timestamp. A correct topological sort
        reorders concurrent events based on process priority.
        """
        report = load_report()
        
        # Timestamp order is just [0, 1, 2, ..., 31]
        timestamp_order = list(range(32))
        causal_order = report["causal_order"]
        
        assert causal_order != timestamp_order, (
            "Causal order equals timestamp order. This suggests the implementation "
            "is sorting by physical timestamp instead of computing a topological "
            "sort of the happens-before partial order. Physical time != logical time "
            "in distributed systems."
        )

    def test_concurrent_event_count(self):
        """Exactly 44 event pairs must be identified as concurrent.
        
        With 32 events there are 496 total pairs.
        Correct analysis: 452 happens-before + 44 concurrent = 496.
        
        If concurrent detection only catches equal clocks (instead of
        mutually non-dominating clocks), the count will be near 0.
        """
        report = load_report()
        assert report["concurrent_count"] == 44, (
            f"Expected exactly 44 concurrent pairs, got {report['concurrent_count']}. "
            f"Common errors: 0-1 (checking clock equality instead of mutual non-dominance), "
            f"or wrong total due to incorrect clock values from a missing increment."
        )

    def test_happens_before_transitivity(self):
        """The happens-before relation must be transitive AND the counts must sum correctly.
        
        Verifies:
        1. transitivity_holds is True
        2. happens_before_count + concurrent_count = 496 (total pairs)
        3. The happens-before count doesn't exceed the theoretical maximum
           for a 32-event trace with 3 processes
        """
        report = load_report()
        
        assert report["transitivity_holds"] is True, (
            "Transitivity check failed. This indicates either incorrect vector "
            "clock values or a bug in happens-before detection."
        )
        
        total_pairs = 32 * 31 // 2  # 496
        hb = report["happens_before_count"]
        conc = report["concurrent_count"]
        
        assert hb + conc == total_pairs, (
            f"HB ({hb}) + concurrent ({conc}) = {hb + conc}, expected {total_pairs}. "
            f"Every pair must be classified as either happens-before or concurrent."
        )
        
        # With 3 processes and concurrent activity, there MUST be concurrent pairs
        # A system with 0 concurrent pairs would mean total causal ordering exists,
        # which is impossible for 3 independent processes with only 9 messages
        assert conc >= 20, (
            f"Only {conc} concurrent pairs detected. With 3 processes and limited "
            f"message passing, dozens of event pairs must be causally unrelated. "
            f"A count near 0 indicates broken concurrent detection."
        )


# =============================================================================
# TIER 4: Full consistency tests (need ALL bugs fixed)
# =============================================================================

class TestTier4FullConsistency:
    """Tests that require all bugs to be fixed simultaneously."""

    def test_causal_fingerprint(self):
        """The causal graph fingerprint must match the expected value.
        
        This is a SHA-256 hash of the complete causal graph structure.
        It depends on:
        - Correct vector clock values (Bug 1)
        - Correct happens-before detection (Bug 2)  
        - Correct concurrent detection (Bug 3)
        - Correct fingerprint computation (Bug 4)
        
        All four bugs must be fixed for this to match.
        """
        report = load_report()
        expected_fingerprint = "71b866fdd5dbfb8c"
        assert report["causal_fingerprint"] == expected_fingerprint, (
            f"Causal fingerprint mismatch. Expected '{expected_fingerprint}', "
            f"got '{report['causal_fingerprint']}'. This hash depends on the entire "
            f"causal graph being correct."
        )

    def test_full_consistency(self):
        """Cross-validate all metrics for internal consistency.
        
        Verifies:
        - Exact happens-before count (452) and concurrent count (44)
        - HB + concurrent = 496 (total pairs)
        - Causal order is NOT timestamp order
        - Causal order is a valid permutation
        - Clock values at final events are maximal
        
        This test requires all bugs to be fixed because it checks
        exact counts (need Bug 1 + Bug 3), ordering (need Bug 2),
        and final clock values (need Bug 1).
        """
        report = load_report()
        state = load_state()
        
        # Exact counts check (needs Bug 1 for correct clocks + Bug 3 for correct classification)
        assert report["happens_before_count"] == 452, (
            f"Expected 452 happens-before pairs, got {report['happens_before_count']}"
        )
        assert report["concurrent_count"] == 44, (
            f"Expected 44 concurrent pairs, got {report['concurrent_count']}"
        )
        
        # Sum check
        n = report["total_events"]
        total_pairs = n * (n - 1) // 2
        hb = report["happens_before_count"]
        conc = report["concurrent_count"]
        assert hb + conc == total_pairs, (
            f"HB ({hb}) + concurrent ({conc}) = {hb + conc}, expected {total_pairs}"
        )
        
        # Causal order must not be timestamp order (needs Bug 2 fixed)
        timestamp_order = list(range(n))
        assert report["causal_order"] != timestamp_order, (
            "Causal order should differ from timestamp order"
        )
        
        # Causal order completeness
        assert sorted(report["causal_order"]) == list(range(n)), (
            "Causal order must be a permutation of all event indices"
        )
        
        # Final clock values (needs Bug 1 for correct increment cascade)
        p1_last = None
        for record in reversed(state):
            if record["process"] == "P1":
                p1_last = record
                break
        assert p1_last is not None
        assert p1_last["vector_clock"]["P1"] == 12, (
            f"P1's final clock component should be 12, got {p1_last['vector_clock']['P1']}"
        )
        
        p2_last = None
        for record in reversed(state):
            if record["process"] == "P2":
                p2_last = record
                break
        assert p2_last is not None
        assert p2_last["vector_clock"]["P2"] == 11, (
            f"P2's final clock component should be 11, got {p2_last['vector_clock']['P2']}"
        )
        
        p3_last = None
        for record in reversed(state):
            if record["process"] == "P3":
                p3_last = record
                break
        assert p3_last is not None
        assert p3_last["vector_clock"]["P3"] == 9, (
            f"P3's final clock component should be 9, got {p3_last['vector_clock']['P3']}"
        )
