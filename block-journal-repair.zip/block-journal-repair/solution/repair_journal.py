#!/usr/bin/env python3
"""
Oracle — correct implementation of journal replay.

Re-processes the journal log with all bugs fixed:
1. ABORT correctly rolls back allocations
2. Free list maintained in sorted order
3. Checkpoint validation uses sequence numbers (not timestamps)
4. Utilization denominator excludes reserved blocks
5. Fingerprint uses correct utilization values
"""

import os
import sys
import json
import hashlib

# Paths
RUNTIME_DIR = '/app/runtime'
JOURNAL_PATH = os.path.join(RUNTIME_DIR, 'txn_journal.log')
BLOCK_STATE_PATH = os.path.join(RUNTIME_DIR, 'block_state.jsonl')
REPORT_PATH = os.path.join(RUNTIME_DIR, 'journal_report.json')


def parse_journal(filepath):
    """Parse journal log file into structured records."""
    records = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split('|')
            if len(parts) != 5:
                continue
            timestamp = int(parts[0])
            seq_num = int(parts[1])
            txn_id = parts[2]
            event_type = parts[3]
            payload_raw = parts[4]

            payload = {}
            for item in payload_raw.split(','):
                if '=' in item:
                    key, value = item.split('=', 1)
                    payload[key] = value

            if 'blocks' in payload:
                block_range = payload['blocks']
                if '-' in block_range:
                    start, end = block_range.split('-')
                    payload['blocks'] = list(range(int(start), int(end) + 1))
                else:
                    payload['blocks'] = [int(block_range)]

            records.append({
                'timestamp': timestamp,
                'seq_num': seq_num,
                'txn_id': txn_id,
                'event_type': event_type,
                'payload': payload,
            })
    return records


class CorrectBlockGroup:
    """Block group with correct behavior."""

    def __init__(self, group_id, total_blocks=64, reserved_blocks=8):
        self.group_id = group_id
        self.total_blocks = total_blocks
        self.reserved_blocks = reserved_blocks
        self.allocated = set()
        self.free_list = list(range(reserved_blocks, total_blocks))
        self.txn_allocations = {}

    def alloc_blocks(self, txn_id, blocks):
        for b in blocks:
            if b in self.free_list:
                self.free_list.remove(b)
                self.allocated.add(b)
        if txn_id not in self.txn_allocations:
            self.txn_allocations[txn_id] = []
        self.txn_allocations[txn_id].extend(blocks)

    def free_blocks(self, txn_id, blocks):
        for b in blocks:
            if b in self.allocated:
                self.allocated.remove(b)
                # FIX Bug 2: Insert in sorted position (not append/LIFO)
                self.free_list.append(b)
                self.free_list.sort()

    def commit(self, txn_id):
        if txn_id in self.txn_allocations:
            del self.txn_allocations[txn_id]

    def abort(self, txn_id):
        # FIX Bug 1: Rollback allocations on abort
        if txn_id in self.txn_allocations:
            for b in self.txn_allocations[txn_id]:
                if b in self.allocated:
                    self.allocated.remove(b)
                    self.free_list.append(b)
                    self.free_list.sort()
            del self.txn_allocations[txn_id]

    def get_state(self):
        return {
            'block_group': self.group_id,
            'total_blocks': self.total_blocks,
            'reserved_blocks': self.reserved_blocks,
            'allocated_blocks': sorted(list(self.allocated)),
            'free_blocks': sorted(self.free_list),
        }


def process_journal(records):
    """Process journal records with correct logic."""
    groups = {}
    transactions = {}

    for record in records:
        event = record['event_type']
        txn_id = record['txn_id']
        payload = record['payload']

        if event == 'BEGIN':
            group_id = payload.get('block_group', '')
            if group_id not in groups:
                groups[group_id] = CorrectBlockGroup(group_id)
            transactions[txn_id] = group_id

        elif event == 'ALLOC':
            group_id = payload.get('block_group', '')
            blocks = payload.get('blocks', [])
            if group_id not in groups:
                groups[group_id] = CorrectBlockGroup(group_id)
            groups[group_id].alloc_blocks(txn_id, blocks)

        elif event == 'FREE':
            group_id = payload.get('block_group', '')
            blocks = payload.get('blocks', [])
            if group_id not in groups:
                groups[group_id] = CorrectBlockGroup(group_id)
            groups[group_id].free_blocks(txn_id, blocks)

        elif event == 'COMMIT':
            group_id = payload.get('block_group', '')
            if group_id and group_id in groups:
                groups[group_id].commit(txn_id)

        elif event == 'ABORT':
            group_id = payload.get('block_group', '')
            if group_id and group_id in groups:
                groups[group_id].abort(txn_id)

    states = {}
    for group_id in sorted(groups.keys()):
        states[group_id] = groups[group_id].get_state()
    return states


def validate_checkpoints_correct(records):
    """Validate checkpoints using sequence numbers (FIX Bug 3)."""
    committed_txns = []
    for rec in records:
        if rec['event_type'] == 'COMMIT':
            committed_txns.append({
                'txn_id': rec['txn_id'],
                'timestamp': rec['timestamp'],
                'seq_num': rec['seq_num'],
            })

    # FIX Bug 3: Sort by sequence number, not timestamp
    committed_txns.sort(key=lambda x: x['seq_num'])

    checkpoints = []
    for rec in records:
        if rec['event_type'] == 'CHECKPOINT':
            payload = rec['payload']
            seq_start = int(payload.get('seq_start', '0'))
            seq_end = int(payload.get('seq_end', '0'))
            checkpoints.append({
                'txn_id': rec['txn_id'],
                'seq_start': seq_start,
                'seq_end': seq_end,
                'timestamp': rec['timestamp'],
                'seq_num': rec['seq_num'],
            })

    if not checkpoints:
        return True

    for cp in checkpoints:
        range_txns = []
        for ct in committed_txns:
            if cp['seq_start'] <= ct['seq_num'] <= cp['seq_end']:
                range_txns.append(ct)

        for i in range(len(range_txns) - 1):
            if range_txns[i]['seq_num'] > range_txns[i + 1]['seq_num']:
                return False

    return True


def compute_utilization_correct(state):
    """FIX Bug 4: Use (total - reserved) as denominator."""
    allocated_count = len(state['allocated_blocks'])
    usable = state['total_blocks'] - state['reserved_blocks']
    return allocated_count / usable


def compute_fingerprint_correct(states):
    """FIX Bug 5: Uses sorted iteration and correct utilization."""
    hasher = hashlib.sha256()
    for group_id in sorted(states.keys()):
        state = states[group_id]
        utilization = compute_utilization_correct(state)
        canonical = json.dumps({
            'block_group': state['block_group'],
            'allocated_blocks': state['allocated_blocks'],
            'free_blocks': state['free_blocks'],
            'utilization': round(utilization, 6),
        }, sort_keys=True)
        hasher.update(canonical.encode('utf-8'))
    return hasher.hexdigest()


def generate_report_correct(states, records, checkpoint_valid):
    """Generate correct report."""
    txn_ids = set()
    committed = set()
    aborted = set()
    for rec in records:
        txn_ids.add(rec['txn_id'])
        if rec['event_type'] == 'COMMIT':
            committed.add(rec['txn_id'])
        elif rec['event_type'] == 'ABORT':
            aborted.add(rec['txn_id'])

    block_groups = {}
    for group_id in sorted(states.keys()):
        state = states[group_id]
        alloc_count = len(state['allocated_blocks'])
        free_count = len(state['free_blocks'])
        utilization = compute_utilization_correct(state)
        block_groups[group_id] = {
            'allocated': alloc_count,
            'free': free_count,
            'utilization': round(utilization, 6),
        }

    fingerprint = compute_fingerprint_correct(states)

    report = {
        'total_transactions': len(txn_ids),
        'committed': len(committed),
        'aborted': len(aborted),
        'block_groups': block_groups,
        'checkpoint_valid': checkpoint_valid,
        'integrity_fingerprint': fingerprint,
    }
    return report


def main():
    records = parse_journal(JOURNAL_PATH)
    print(f"[oracle] Parsed {len(records)} records")

    states = process_journal(records)
    print(f"[oracle] Processed {len(states)} block groups")

    checkpoint_valid = validate_checkpoints_correct(records)
    print(f"[oracle] Checkpoint validation: {'PASS' if checkpoint_valid else 'FAIL'}")

    # Write block state
    with open(BLOCK_STATE_PATH, 'w') as f:
        for group_id in sorted(states.keys()):
            f.write(json.dumps(states[group_id]) + '\n')
    print(f"[oracle] Wrote {BLOCK_STATE_PATH}")

    # Write report
    report = generate_report_correct(states, records, checkpoint_valid)
    with open(REPORT_PATH, 'w') as f:
        json.dump(report, f, indent=2)
        f.write('\n')
    print(f"[oracle] Wrote {REPORT_PATH}")
    print(f"[oracle] Fingerprint: {report['integrity_fingerprint']}")

    return 0


if __name__ == '__main__':
    sys.exit(main())
