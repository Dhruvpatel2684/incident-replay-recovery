#!/bin/bash
set -e
python3 /app/runtime/journal_replay.py
python3 /solution/repair_journal.py
