# Block Journal Replay — Incident Report

## Background

Hey — so we've got a situation with our block journal replayer tool. Quick context: we use this internally to audit filesystem transaction journals (think ext4-style journaling). The tool reads a journal log, replays all the transactions, and spits out the reconstructed block allocation state plus a summary report. It's been working fine in staging for weeks, but now that we're running it against production journals, the numbers are off.

## What's Happening

We ran the replayer against a journal (`txn_journal.log`) from one of our storage nodes and the output doesn't match what the actual on-disk allocator reports. Specifically:

- The total allocated block count is higher than expected
- The utilization percentage seems inflated
- The integrity fingerprint doesn't match what our reference fsck tool computes
- There's something weird with checkpoint validation — it's flagging valid checkpoints as inconsistent

The tool does produce output — it doesn't crash or throw exceptions. It just produces *wrong* output. The files it generates look structurally fine but the values are incorrect.

## System Layout

Everything runs in `/app/runtime/`. The entrypoint is `journal_replay.py` which orchestrates the pipeline:

1. `journal_parser.py` — parses `txn_journal.log` into structured records
2. `block_allocator.py` — state machine that tracks block allocation per group
3. `integrity_checker.py` — validates checkpoint consistency
4. `report_writer.py` — produces the final output files

The input journal and both output files all live in `/app/runtime/`.

Python 3.11 is available system-wide. No additional packages needed beyond stdlib.

## Input Format

The journal file (`txn_journal.log`) uses pipe-delimited fields:

```
TIMESTAMP|SEQ_NUM|TXN_ID|EVENT_TYPE|PAYLOAD
```

Event types: `BEGIN`, `ALLOC`, `FREE`, `COMMIT`, `ABORT`, `CHECKPOINT`

## Output Files

### `block_state.jsonl`

One JSON object per line, one per block group:

```json
{"block_group": "bg-0", "total_blocks": 64, "reserved_blocks": 8, "allocated_blocks": [...], "free_blocks": [...]}
```

- `block_group`: string identifier
- `total_blocks`: int, total blocks in the group
- `reserved_blocks`: int, blocks reserved by the filesystem (blocks 0 through reserved-1)
- `allocated_blocks`: sorted list of ints — block numbers currently allocated (excluding reserved)
- `free_blocks`: sorted list of ints — block numbers currently free (excluding reserved)

### `journal_report.json`

```json
{
  "total_transactions": int,
  "committed": int,
  "aborted": int,
  "block_groups": {
    "bg-X": {"allocated": int, "free": int, "utilization": float}
  },
  "checkpoint_valid": bool,
  "integrity_fingerprint": str
}
```

- `utilization`: ratio of allocated usable blocks to total usable capacity
- `checkpoint_valid`: whether the checkpoint sequence is internally consistent
- `integrity_fingerprint`: SHA-256 hex digest of the canonical block state

## What I Need

Fix whatever's wrong so the replayer produces correct output. The parser and entrypoint are fine — I've verified those manually. The bugs are somewhere in the allocator, checker, or report writer.

Don't modify the journal log or the parser. Just fix the processing logic.

Good luck, and let me know if the checkpoint ordering thing doesn't make sense — that one's subtle.
