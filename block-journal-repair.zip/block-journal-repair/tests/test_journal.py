"""
Test suite for block journal replay — 14 tests in 4 tiers.

Tier 1 (7): Pass with buggy code (structural checks)
Tier 2 (3): Require Bug 1 or Bug 2 fixed (allocation correctness)
Tier 3 (2): Require Bug 3 or Bug 4 fixed (validation/metrics)
Tier 4 (2): Require ALL bugs fixed (fingerprint + full consistency)
"""

import json
import os
import hashlib
import sys

# Paths
RUNTIME_DIR = '/app/runtime'
BLOCK_STATE_PATH = os.path.join(RUNTIME_DIR, 'block_state.jsonl')
REPORT_PATH = os.path.join(RUNTIME_DIR, 'journal_report.json')
JOURNAL_PATH = os.path.join(RUNTIME_DIR, 'txn_journal.log')


def load_block_states():
    """Load block_state.jsonl into a dict keyed by block_group."""
    states = {}
    with open(BLOCK_STATE_PATH, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                obj = json.loads(line)
                states[obj['block_group']] = obj
    return states


def load_report():
    """Load journal_report.json."""
    with open(REPORT_PATH, 'r') as f:
        return json.load(f)


# ===========================================================================
# TIER 1 — Structural checks (pass with buggy code)
# ===========================================================================


class TestTier1:
    """Tests that pass even with buggy code — structural validity."""

    def test_output_files_exist(self):
        """Both output files should be generated."""
        assert os.path.isfile(BLOCK_STATE_PATH), f"Missing {BLOCK_STATE_PATH}"
        assert os.path.isfile(REPORT_PATH), f"Missing {REPORT_PATH}"

    def test_three_block_groups(self):
        """Should have exactly 3 block groups in output."""
        states = load_block_states()
        assert len(states) == 3, f"Expected 3 block groups, got {len(states)}"

    def test_block_group_ids(self):
        """Block groups should be bg-0, bg-1, bg-2."""
        states = load_block_states()
        expected_ids = {'bg-0', 'bg-1', 'bg-2'}
        assert set(states.keys()) == expected_ids

    def test_total_blocks_per_group(self):
        """Each block group should have 64 total blocks."""
        states = load_block_states()
        for gid, state in states.items():
            assert state['total_blocks'] == 64, \
                f"{gid}: expected 64 total blocks, got {state['total_blocks']}"

    def test_reserved_blocks_per_group(self):
        """Each block group should have 8 reserved blocks."""
        states = load_block_states()
        for gid, state in states.items():
            assert state['reserved_blocks'] == 8, \
                f"{gid}: expected 8 reserved, got {state['reserved_blocks']}"

    def test_report_has_required_fields(self):
        """Report should have all required top-level fields."""
        report = load_report()
        required = ['total_transactions', 'committed', 'aborted',
                    'block_groups', 'checkpoint_valid', 'integrity_fingerprint']
        for field in required:
            assert field in report, f"Missing field: {field}"

    def test_committed_transactions_count(self):
        """Should report 8 committed and 2 aborted transactions."""
        report = load_report()
        assert report['total_transactions'] == 10, \
            f"Expected 10 total txns, got {report['total_transactions']}"
        assert report['committed'] == 8, \
            f"Expected 8 committed, got {report['committed']}"
        assert report['aborted'] == 2, \
            f"Expected 2 aborted, got {report['aborted']}"


# ===========================================================================
# TIER 2 — Require Bug 1 or Bug 2 fixed
# ===========================================================================


class TestTier2:
    """Tests that require abort rollback and free-list ordering fixes."""

    def test_aborted_blocks_freed(self):
        """Blocks allocated by aborted transactions must not remain allocated.

        txn-004 allocated blocks 16-19 in bg-0 then ABORT -> should be free.
        txn-007 allocated blocks 16-19 in bg-2 then ABORT -> should be free.
        """
        states = load_block_states()

        # bg-0: blocks 16-19 from aborted txn-004 should NOT be allocated
        bg0_alloc = states['bg-0']['allocated_blocks']
        for b in [16, 17, 18, 19]:
            assert b not in bg0_alloc, \
                f"bg-0 block {b} should be free (txn-004 was aborted)"

        # bg-2: blocks 16-19 from aborted txn-007 should NOT be allocated
        bg2_alloc = states['bg-2']['allocated_blocks']
        for b in [16, 17, 18, 19]:
            assert b not in bg2_alloc, \
                f"bg-2 block {b} should be free (txn-007 was aborted)"

    def test_free_list_ordering(self):
        """Free list must be sorted in ascending order by block number."""
        states = load_block_states()
        for gid, state in states.items():
            free_list = state['free_blocks']
            assert free_list == sorted(free_list), \
                f"{gid}: free list is not sorted: {free_list[:10]}..."

    def test_total_allocated_blocks(self):
        """Total allocated block count across all groups should be exactly 33.

        bg-0: blocks 8,9,12,13,14,15,20,21,22,23 = 10
        bg-1: blocks 11,12,13,14,15,16,17,18,19,20,21 = 11
        bg-2: blocks 8,9,10,11,12,13,14,15,20,21,22,23 = 12
        Total: 33
        """
        states = load_block_states()
        total = sum(len(s['allocated_blocks']) for s in states.values())
        assert total == 33, f"Expected 33 total allocated blocks, got {total}"


# ===========================================================================
# TIER 3 — Require Bug 3 or Bug 4 fixed
# ===========================================================================


class TestTier3:
    """Tests that require checkpoint ordering fix or utilization fix."""

    def test_checkpoint_ordering(self):
        """Checkpoint validation must use sequence numbers, not timestamps.

        txn-009 has timestamps 1716000085-89 (COMMIT seq 45)
        txn-010 has timestamps 1716000080-84 (COMMIT seq 49)
        By timestamp, txn-010's COMMIT appears before txn-009's COMMIT —
        but by seq_num, txn-009 correctly precedes txn-010.

        With correct seq_num ordering, the checkpoint should validate as True.
        """
        report = load_report()
        assert report['checkpoint_valid'] is True, \
            "Checkpoint should be valid when ordered by sequence number"

    def test_utilization_rate(self):
        """Utilization should use (total - reserved) as denominator.

        Each group has 64 total, 8 reserved -> 56 usable blocks.
        bg-0: 10/56 ≈ 0.178571
        bg-1: 11/56 ≈ 0.196429
        bg-2: 12/56 ≈ 0.214286
        """
        report = load_report()
        bg = report['block_groups']

        # bg-0: 10 allocated / 56 usable
        expected_bg0 = round(10 / 56, 6)
        assert abs(bg['bg-0']['utilization'] - expected_bg0) < 1e-5, \
            f"bg-0 utilization: expected {expected_bg0}, got {bg['bg-0']['utilization']}"

        # bg-1: 11 allocated / 56 usable
        expected_bg1 = round(11 / 56, 6)
        assert abs(bg['bg-1']['utilization'] - expected_bg1) < 1e-5, \
            f"bg-1 utilization: expected {expected_bg1}, got {bg['bg-1']['utilization']}"

        # bg-2: 12 allocated / 56 usable
        expected_bg2 = round(12 / 56, 6)
        assert abs(bg['bg-2']['utilization'] - expected_bg2) < 1e-5, \
            f"bg-2 utilization: expected {expected_bg2}, got {bg['bg-2']['utilization']}"


# ===========================================================================
# TIER 4 — Require ALL bugs fixed
# ===========================================================================


class TestTier4:
    """Tests that require all 5 bugs to be fixed simultaneously."""

    def test_integrity_fingerprint(self):
        """Fingerprint must match the canonical correct computation.

        The fingerprint hashes over sorted block groups with correct utilization.
        This test recomputes the expected fingerprint from the block state file.
        """
        states = load_block_states()
        report = load_report()

        # Recompute expected fingerprint with correct utilization
        hasher = hashlib.sha256()
        for group_id in sorted(states.keys()):
            state = states[group_id]
            usable = state['total_blocks'] - state['reserved_blocks']
            utilization = len(state['allocated_blocks']) / usable
            canonical = json.dumps({
                'block_group': state['block_group'],
                'allocated_blocks': state['allocated_blocks'],
                'free_blocks': state['free_blocks'],
                'utilization': round(utilization, 6),
            }, sort_keys=True)
            hasher.update(canonical.encode('utf-8'))
        expected_fp = hasher.hexdigest()

        assert report['integrity_fingerprint'] == expected_fp, \
            f"Fingerprint mismatch:\n  got:      {report['integrity_fingerprint']}\n  expected: {expected_fp}"

    def test_allocation_bitmap_consistency(self):
        """Cross-validate all output: sorted free lists, correct counts,
        valid checkpoint, and matching fingerprint.

        This test only passes when all bugs are fixed because it checks:
        - Free list sorted (Bug 2)
        - Correct allocated count implies abort rollback (Bug 1)
        - Checkpoint validity (Bug 3)
        - Utilization in report matches recomputed from state (Bug 4)
        - No overlap, full coverage of usable range
        """
        states = load_block_states()
        report = load_report()

        total_allocated = 0
        for gid, state in states.items():
            total = state['total_blocks']
            reserved = state['reserved_blocks']
            allocated = state['allocated_blocks']
            free = state['free_blocks']

            # Free list must be sorted (Bug 2)
            assert free == sorted(free), \
                f"{gid}: free list not sorted"

            # No overlap between allocated and free
            assert len(set(allocated) & set(free)) == 0, \
                f"{gid}: overlap between allocated and free"

            # All in valid usable range
            usable_range = set(range(reserved, total))
            assert set(allocated) | set(free) == usable_range, \
                f"{gid}: allocated + free != usable range"

            # Counts add up
            assert len(allocated) + len(free) + reserved == total, \
                f"{gid}: count mismatch"

            # Verify utilization in report matches state (Bug 4)
            usable = total - reserved
            expected_util = round(len(allocated) / usable, 6)
            report_util = report['block_groups'][gid]['utilization']
            assert abs(report_util - expected_util) < 1e-5, \
                f"{gid}: utilization mismatch in report"

            total_allocated += len(allocated)

        # Total must be 33 (Bug 1 - abort rollback)
        assert total_allocated == 33, \
            f"Total allocated {total_allocated} != 33"

        # Checkpoint must be valid (Bug 3)
        assert report['checkpoint_valid'] is True, \
            "Checkpoint should be valid"
