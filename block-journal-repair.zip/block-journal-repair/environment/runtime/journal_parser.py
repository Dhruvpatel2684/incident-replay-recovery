"""
Journal Parser — parses txn_journal.log into structured records.

Input format: TIMESTAMP|SEQ_NUM|TXN_ID|EVENT_TYPE|PAYLOAD
"""


def parse_journal(filepath):
    """Parse journal log file and return list of structured records."""
    records = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split('|')
            if len(parts) != 5:
                continue
            timestamp = int(parts[0])
            seq_num = int(parts[1])
            txn_id = parts[2]
            event_type = parts[3]
            payload_raw = parts[4]

            # Parse payload into key-value pairs
            payload = {}
            for item in payload_raw.split(','):
                if '=' in item:
                    key, value = item.split('=', 1)
                    payload[key] = value

            # Expand block ranges like "8-11" into list [8, 9, 10, 11]
            if 'blocks' in payload:
                block_range = payload['blocks']
                if '-' in block_range:
                    start, end = block_range.split('-')
                    payload['blocks'] = list(range(int(start), int(end) + 1))
                else:
                    payload['blocks'] = [int(block_range)]

            records.append({
                'timestamp': timestamp,
                'seq_num': seq_num,
                'txn_id': txn_id,
                'event_type': event_type,
                'payload': payload,
            })
    return records
