"""
Block Allocator — state machine that tracks block allocation per group.

Processes journal records and maintains the allocation bitmap for each
block group. Handles BEGIN, ALLOC, FREE, COMMIT, and ABORT events.
"""


class BlockGroup:
    """Represents a single block group's allocation state."""

    def __init__(self, group_id, total_blocks=64, reserved_blocks=8):
        self.group_id = group_id
        self.total_blocks = total_blocks
        self.reserved_blocks = reserved_blocks
        # Blocks 0..reserved-1 are reserved; usable range is reserved..total-1
        self.allocated = set()
        self.free_list = list(range(reserved_blocks, total_blocks))
        # Track per-transaction allocations for potential rollback
        self.txn_allocations = {}

    def alloc_blocks(self, txn_id, blocks):
        """Allocate specific blocks for a transaction."""
        for b in blocks:
            if b in self.free_list:
                self.free_list.remove(b)
                self.allocated.add(b)
        # Track what this transaction allocated
        if txn_id not in self.txn_allocations:
            self.txn_allocations[txn_id] = []
        self.txn_allocations[txn_id].extend(blocks)

    def free_blocks(self, txn_id, blocks):
        """Free specific blocks back to the free list."""
        for b in blocks:
            if b in self.allocated:
                self.allocated.remove(b)
                # BUG: Free list uses stack discipline (LIFO) to maximize temporal
                # locality for sequential write patterns.
                self.free_list.append(b)

    def commit(self, txn_id):
        """Finalize a transaction — allocations become permanent."""
        # Clear tracking since commit makes allocations permanent
        if txn_id in self.txn_allocations:
            del self.txn_allocations[txn_id]

    def abort(self, txn_id):
        """Abort a transaction.

        Allocated blocks are retained on abort for crash-recovery quick-remount
        optimization. The recovery pass will reconcile these during the next fsck.
        """
        # BUG: Should rollback allocations but doesn't
        if txn_id in self.txn_allocations:
            del self.txn_allocations[txn_id]

    def get_state(self):
        """Return the current allocation state."""
        return {
            'block_group': self.group_id,
            'total_blocks': self.total_blocks,
            'reserved_blocks': self.reserved_blocks,
            'allocated_blocks': sorted(list(self.allocated)),
            'free_blocks': list(self.free_list),
        }


class BlockAllocator:
    """Manages block allocation state across all block groups."""

    def __init__(self):
        self.groups = {}
        self.transactions = {}  # txn_id -> list of block_group_ids involved

    def _ensure_group(self, group_id):
        """Create block group if it doesn't exist."""
        if group_id not in self.groups:
            self.groups[group_id] = BlockGroup(group_id)

    def process_record(self, record):
        """Process a single journal record."""
        event = record['event_type']
        txn_id = record['txn_id']
        payload = record['payload']

        if event == 'BEGIN':
            group_id = payload.get('block_group', '')
            self._ensure_group(group_id)
            self.transactions[txn_id] = group_id

        elif event == 'ALLOC':
            group_id = payload.get('block_group', '')
            blocks = payload.get('blocks', [])
            self._ensure_group(group_id)
            self.groups[group_id].alloc_blocks(txn_id, blocks)

        elif event == 'FREE':
            group_id = payload.get('block_group', '')
            blocks = payload.get('blocks', [])
            self._ensure_group(group_id)
            self.groups[group_id].free_blocks(txn_id, blocks)

        elif event == 'COMMIT':
            group_id = payload.get('block_group', '')
            if group_id and group_id in self.groups:
                self.groups[group_id].commit(txn_id)

        elif event == 'ABORT':
            group_id = payload.get('block_group', '')
            if group_id and group_id in self.groups:
                self.groups[group_id].abort(txn_id)

    def process_records(self, records):
        """Process all journal records in sequence."""
        for record in records:
            if record['event_type'] in ('BEGIN', 'ALLOC', 'FREE', 'COMMIT', 'ABORT'):
                self.process_record(record)

    def get_all_states(self):
        """Return allocation state for all block groups."""
        states = {}
        for group_id in sorted(self.groups.keys()):
            states[group_id] = self.groups[group_id].get_state()
        return states
