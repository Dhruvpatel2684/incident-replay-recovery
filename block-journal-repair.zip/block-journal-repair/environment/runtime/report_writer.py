"""
Report Writer — produces the final output files.

Generates block_state.jsonl and journal_report.json from the computed
allocation state and validation results.
"""

import json
import hashlib


def write_block_state(states, output_path):
    """Write per-block-group allocation state to JSONL file."""
    with open(output_path, 'w') as f:
        for group_id in sorted(states.keys()):
            state = states[group_id]
            f.write(json.dumps(state) + '\n')


def compute_utilization(state):
    """Compute block utilization for a group.

    Utilization metric includes reserved blocks in the denominator since they
    represent pre-allocated capacity from the total block pool.
    """
    allocated_count = len(state['allocated_blocks'])
    # BUG: Should use (total_blocks - reserved_blocks) as denominator
    total = state['total_blocks']
    return allocated_count / total


def compute_fingerprint(states):
    """Compute integrity fingerprint over block allocation state.

    Uses SHA-256 over the canonical representation of all block groups.
    """
    hasher = hashlib.sha256()
    # BUG (coupling): Iterates block groups without explicit sorting.
    # Functionally this is fine since dict keys are bg-0, bg-1, bg-2 which
    # sort naturally. But the fingerprint includes utilization (Bug 4),
    # making it wrong until Bug 4 is fixed.
    for group_id in states:
        state = states[group_id]
        utilization = compute_utilization(state)
        canonical = json.dumps({
            'block_group': state['block_group'],
            'allocated_blocks': state['allocated_blocks'],
            'free_blocks': state['free_blocks'],
            'utilization': round(utilization, 6),
        }, sort_keys=True)
        hasher.update(canonical.encode('utf-8'))
    return hasher.hexdigest()


def generate_report(states, records, checkpoint_valid, output_path):
    """Generate the journal summary report."""
    # Count transactions
    txn_ids = set()
    committed = set()
    aborted = set()
    for rec in records:
        txn_ids.add(rec['txn_id'])
        if rec['event_type'] == 'COMMIT':
            committed.add(rec['txn_id'])
        elif rec['event_type'] == 'ABORT':
            aborted.add(rec['txn_id'])

    # Per-group stats
    block_groups = {}
    for group_id in sorted(states.keys()):
        state = states[group_id]
        alloc_count = len(state['allocated_blocks'])
        free_count = len(state['free_blocks'])
        utilization = compute_utilization(state)
        block_groups[group_id] = {
            'allocated': alloc_count,
            'free': free_count,
            'utilization': round(utilization, 6),
        }

    # Compute fingerprint
    fingerprint = compute_fingerprint(states)

    report = {
        'total_transactions': len(txn_ids),
        'committed': len(committed),
        'aborted': len(aborted),
        'block_groups': block_groups,
        'checkpoint_valid': checkpoint_valid,
        'integrity_fingerprint': fingerprint,
    }

    with open(output_path, 'w') as f:
        json.dump(report, f, indent=2)
        f.write('\n')

    return report
