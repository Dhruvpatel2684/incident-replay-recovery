#!/usr/bin/env python3
"""
Journal Replay — entrypoint that orchestrates the full pipeline.

Reads txn_journal.log, processes through the block allocator,
validates checkpoints, and writes output files.
"""

import os
import sys

# Add runtime directory to path
runtime_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, runtime_dir)

from journal_parser import parse_journal
from block_allocator import BlockAllocator
from integrity_checker import validate_checkpoints
from report_writer import write_block_state, generate_report


def main():
    """Main replay pipeline."""
    journal_path = os.path.join(runtime_dir, 'txn_journal.log')
    block_state_path = os.path.join(runtime_dir, 'block_state.jsonl')
    report_path = os.path.join(runtime_dir, 'journal_report.json')

    # Step 1: Parse the journal
    records = parse_journal(journal_path)
    print(f"Parsed {len(records)} journal records")

    # Step 2: Process through block allocator
    allocator = BlockAllocator()
    allocator.process_records(records)
    states = allocator.get_all_states()
    print(f"Processed {len(states)} block groups")

    # Step 3: Validate checkpoints
    checkpoint_valid = validate_checkpoints(records)
    print(f"Checkpoint validation: {'PASS' if checkpoint_valid else 'FAIL'}")

    # Step 4: Write output files
    write_block_state(states, block_state_path)
    print(f"Wrote block state to {block_state_path}")

    report = generate_report(states, records, checkpoint_valid, report_path)
    print(f"Wrote report to {report_path}")
    print(f"  Total transactions: {report['total_transactions']}")
    print(f"  Committed: {report['committed']}")
    print(f"  Aborted: {report['aborted']}")
    print(f"  Fingerprint: {report['integrity_fingerprint']}")

    return 0


if __name__ == '__main__':
    sys.exit(main())
