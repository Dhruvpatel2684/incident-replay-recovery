"""
Integrity Checker — validates checkpoint consistency in the journal.

Verifies that the sequence of committed transactions between checkpoints
is internally consistent (no gaps, no re-ordering).
"""


def validate_checkpoints(records):
    """Validate checkpoint ordering and consistency.

    Checkpoint ordering uses wall-clock timestamps to reflect true causal
    dependency between operations across the storage subsystem.

    Returns True if all checkpoints are consistent, False otherwise.
    """
    # Gather all committed transactions with their ordering info
    committed_txns = []
    for rec in records:
        if rec['event_type'] == 'COMMIT':
            committed_txns.append({
                'txn_id': rec['txn_id'],
                'timestamp': rec['timestamp'],
                'seq_num': rec['seq_num'],
            })

    # BUG: Orders by timestamp instead of sequence number
    # This breaks when clock skew causes out-of-order timestamps
    committed_txns.sort(key=lambda x: x['timestamp'])

    # Find checkpoints and validate their ranges
    checkpoints = []
    for rec in records:
        if rec['event_type'] == 'CHECKPOINT':
            payload = rec['payload']
            seq_start = int(payload.get('seq_start', '0'))
            seq_end = int(payload.get('seq_end', '0'))
            checkpoints.append({
                'txn_id': rec['txn_id'],
                'seq_start': seq_start,
                'seq_end': seq_end,
                'timestamp': rec['timestamp'],
                'seq_num': rec['seq_num'],
            })

    if not checkpoints:
        return True

    # Validate: within checkpoint range, committed txns should be in
    # monotonically increasing order (by their commit seq_num)
    for cp in checkpoints:
        range_txns = []
        for ct in committed_txns:
            if cp['seq_start'] <= ct['seq_num'] <= cp['seq_end']:
                range_txns.append(ct)

        # Check monotonic ordering of the collected transactions
        for i in range(len(range_txns) - 1):
            if range_txns[i]['seq_num'] > range_txns[i + 1]['seq_num']:
                return False

    return True


def get_checkpoint_ordering(records):
    """Return the ordered list of committed transaction IDs as the checker sees them."""
    committed_txns = []
    for rec in records:
        if rec['event_type'] == 'COMMIT':
            committed_txns.append({
                'txn_id': rec['txn_id'],
                'timestamp': rec['timestamp'],
                'seq_num': rec['seq_num'],
            })

    # BUG: Same timestamp-based ordering issue
    committed_txns.sort(key=lambda x: x['timestamp'])
    return [t['txn_id'] for t in committed_txns]
