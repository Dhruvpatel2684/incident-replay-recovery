import urllib.request
try:
    r = urllib.request.urlopen('http://localhost:8080/')
    exit(0 if r.status == 200 else 1)
except:
    exit(1)
