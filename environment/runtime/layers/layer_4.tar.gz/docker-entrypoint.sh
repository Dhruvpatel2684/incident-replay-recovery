#!/bin/bash
exec gunicorn --bind 0.0.0.0:8080 --workers ${WORKERS:-4} app.main:app
