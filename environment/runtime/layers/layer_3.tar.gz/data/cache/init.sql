CREATE TABLE sessions (id TEXT PRIMARY KEY, data BLOB, expires INTEGER);
CREATE INDEX idx_expires ON sessions(expires);
