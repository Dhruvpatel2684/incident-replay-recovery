"""
Test suite for WAL compaction tool.

14 tests in 4 tiers:
- Tier 1 (6 tests): Structural checks - pass with buggy code
- Tier 2 (3 tests): Abort rollback checks - need Bug 1 fixed
- Tier 3 (3 tests): Ordering/tombstone checks - need Bugs 2+3 fixed
- Tier 4 (2 tests): Full consistency checks - need all bugs fixed
"""

import json
import os
import hashlib

# Output file paths
RUNTIME_DIR = "/app/runtime"
STATE_PATH = os.path.join(RUNTIME_DIR, "compacted_state.json")
REPORT_PATH = os.path.join(RUNTIME_DIR, "compaction_report.json")


def load_state():
    """Load compacted_state.json."""
    with open(STATE_PATH, "r") as f:
        return json.load(f)


def load_report():
    """Load compaction_report.json."""
    with open(REPORT_PATH, "r") as f:
        return json.load(f)


# =============================================================================
# TIER 1: Structural tests (pass with buggy code)
# =============================================================================

class TestTier1Structural:
    """Basic structural checks that pass even with buggy compaction logic."""

    def test_output_files_exist(self):
        """Both output files must exist after compaction."""
        assert os.path.exists(STATE_PATH), f"Missing: {STATE_PATH}"
        assert os.path.exists(REPORT_PATH), f"Missing: {REPORT_PATH}"

    def test_compacted_state_is_dict(self):
        """Compacted state must be a valid JSON object (dict)."""
        state = load_state()
        assert isinstance(state, dict), "Compacted state must be a JSON object"
        assert len(state) > 0, "Compacted state must not be empty"

    def test_report_has_required_fields(self):
        """Report must contain all required fields."""
        report = load_report()
        required_top = ["compaction_summary", "state_summary", "compaction_fingerprint"]
        for field in required_top:
            assert field in report, f"Missing top-level field: {field}"

        summary_fields = ["total_transactions", "committed_transactions",
                         "aborted_transactions", "total_data_operations"]
        for field in summary_fields:
            assert field in report["compaction_summary"], f"Missing summary field: {field}"

        state_fields = ["live_key_count", "deleted_key_count", "keys"]
        for field in state_fields:
            assert field in report["state_summary"], f"Missing state field: {field}"

    def test_total_transactions_count(self):
        """Total transaction count must be 10."""
        report = load_report()
        assert report["compaction_summary"]["total_transactions"] == 10, (
            f"Expected 10 transactions, got {report['compaction_summary']['total_transactions']}"
        )

    def test_committed_count(self):
        """Committed transaction count must be 8."""
        report = load_report()
        assert report["compaction_summary"]["committed_transactions"] == 8, (
            f"Expected 8 committed, got {report['compaction_summary']['committed_transactions']}"
        )

    def test_aborted_count(self):
        """Aborted transaction count must be 2."""
        report = load_report()
        assert report["compaction_summary"]["aborted_transactions"] == 2, (
            f"Expected 2 aborted, got {report['compaction_summary']['aborted_transactions']}"
        )


# =============================================================================
# TIER 2: Abort rollback tests (need Bug 1 fixed)
# =============================================================================

class TestTier2AbortRollback:
    """Tests that verify aborted transaction changes are not in final state."""

    def test_aborted_keys_not_in_state(self):
        """Keys written ONLY by aborted transactions must not exist in state.

        txn_003 (ABORTED) inserted cache:7001, cache:7002.
        txn_007 (ABORTED) inserted session:3003, event:4001.
        No committed transaction ever wrote these keys, so they must not exist.
        """
        state = load_state()

        # These keys were ONLY written by aborted transactions
        phantom_keys = ["cache:7001", "cache:7002", "session:3003", "event:4001"]
        for key in phantom_keys:
            assert key not in state, (
                f"Key '{key}' exists in compacted state but was only written by an "
                f"aborted transaction. Aborted changes must be rolled back."
            )

    def test_aborted_values_not_visible(self):
        """The reported key list must not include keys only from aborted txns.

        The compaction report's state_summary.keys field lists all live keys.
        Keys that were only written by aborted transactions (cache:7001, cache:7002,
        session:3003, event:4001) must not appear in this list.
        """
        report = load_report()
        reported_keys = set(report["state_summary"]["keys"])

        # These keys were ONLY written by aborted transactions
        phantom_keys = ["cache:7001", "cache:7002", "session:3003", "event:4001"]
        found_phantoms = [k for k in phantom_keys if k in reported_keys]
        assert len(found_phantoms) == 0, (
            f"Report's key list contains phantom keys from aborted transactions: "
            f"{found_phantoms}. These keys were never written by a committed "
            f"transaction and should not appear in the compacted state."
        )

    def test_live_key_count(self):
        """Exactly 12 keys should be live in the compacted state.

        18 unique keys are touched across all transactions, but:
        - 4 keys only written by aborted txns (should not exist)
        - 2 keys deleted by committed txns (should be removed)
        Final: 18 - 4 - 2 = 12 live keys.
        """
        report = load_report()
        assert report["state_summary"]["live_key_count"] == 12, (
            f"Expected 12 live keys, got {report['state_summary']['live_key_count']}. "
            f"If 18: aborted txn changes weren't rolled back AND tombstones weren't applied. "
            f"If 16: aborted txn changes weren't rolled back. "
            f"If 14: tombstones weren't applied."
        )


# =============================================================================
# TIER 3: Ordering and tombstone tests (need Bugs 2+3 fixed)
# =============================================================================

class TestTier3OrderingAndTombstones:
    """Tests that verify LSN-based ordering and tombstone removal."""

    def test_last_writer_wins_by_lsn(self):
        """When multiple committed txns write the same key, highest LSN wins.

        user:1001 is updated by:
        - txn_005 at LSN=24, timestamp=1700000450 -> role="superadmin"
        - txn_006 at LSN=29, timestamp=1700000420 -> role="owner"

        Clock skew: txn_006 has LOWER timestamp but HIGHER LSN.
        Correct (LSN order): txn_006 wins -> role="owner"
        Buggy (timestamp order): txn_005 wins -> role="superadmin"
        """
        state = load_state()
        assert "user:1001" in state, "user:1001 must exist in compacted state"

        user = state["user:1001"]
        assert user["role"] == "owner", (
            f"user:1001 role should be 'owner' (from txn_006, LSN=29), "
            f"got '{user['role']}'. If 'superadmin', conflict resolution is using "
            f"timestamps instead of LSN order. In WAL replay, the log sequence "
            f"number determines write precedence, not wall-clock time."
        )

    def test_tombstone_removes_key(self):
        """DELETE operations from committed txns must remove keys from state.

        txn_005 (committed) DELETEs order:5002 at LSN=26.
        txn_009 (committed) DELETEs session:3002 at LSN=46.
        These keys must NOT appear in the final compacted state.
        """
        state = load_state()

        assert "order:5002" not in state, (
            "order:5002 was DELETEd by committed txn_005 but still exists in state. "
            "Tombstones must remove keys during compaction, not defer to GC."
        )
        assert "session:3002" not in state, (
            "session:3002 was DELETEd by committed txn_009 but still exists in state. "
            "Tombstones must remove keys during compaction, not defer to GC."
        )

    def test_deleted_key_count(self):
        """Exactly 2 keys should be reported as deleted.

        Only committed DELETEs count:
        - txn_005 DELETE order:5002 (committed)
        - txn_009 DELETE session:3002 (committed)

        Aborted DELETEs (txn_003 DELETE session:3001, txn_007 DELETE cache:7001)
        should NOT be counted.
        """
        report = load_report()
        assert report["state_summary"]["deleted_key_count"] == 2, (
            f"Expected 2 deleted keys, got {report['state_summary']['deleted_key_count']}. "
            f"If 4: aborted transaction DELETEs are being counted. "
            f"Only committed DELETEs should be reflected in the compaction report."
        )


# =============================================================================
# TIER 4: Full consistency tests (need ALL bugs fixed)
# =============================================================================

class TestTier4FullConsistency:
    """Tests that require all bugs to be fixed simultaneously."""

    def test_compaction_fingerprint(self):
        """The compaction fingerprint must match the expected value.

        This is a SHA-256 hash of sorted key=value pairs. It depends on:
        - Correct abort rollback (Bug 1) - removes phantom keys
        - Correct LSN ordering (Bug 2) - correct winning values
        - Correct tombstone removal (Bug 3) - removes deleted keys
        - Correct sorted iteration (Bug 4) - deterministic hash

        All four bugs must be fixed for this to match.
        """
        report = load_report()
        expected_fingerprint = "ea8386e7e4f8b5d2"
        assert report["compaction_fingerprint"] == expected_fingerprint, (
            f"Compaction fingerprint mismatch. Expected '{expected_fingerprint}', "
            f"got '{report['compaction_fingerprint']}'. This hash depends on the "
            f"entire compacted state being correct (abort rollback, LSN ordering, "
            f"tombstone removal, and sorted key iteration)."
        )

    def test_full_state_consistency(self):
        """Cross-validate the complete compacted state for internal consistency.

        Verifies:
        - Exact key set matches expected (12 specific keys)
        - Key values are correct for conflict-resolved keys
        - Counts in report match actual state
        - No phantom keys from aborted transactions
        - No tombstoned keys present
        """
        state = load_state()
        report = load_report()

        # Exact expected key set
        expected_keys = sorted([
            "audit:2001", "config:1001", "deploy:1101", "invoice:8001",
            "metric:9001", "metric:9002", "notification:6001", "order:5001",
            "order:5003", "session:3001", "user:1001", "user:1002"
        ])
        actual_keys = sorted(state.keys())
        assert actual_keys == expected_keys, (
            f"Key set mismatch.\n"
            f"Expected: {expected_keys}\n"
            f"Got: {actual_keys}\n"
            f"Extra: {sorted(set(actual_keys) - set(expected_keys))}\n"
            f"Missing: {sorted(set(expected_keys) - set(actual_keys))}"
        )

        # Verify conflict-resolved values
        assert state["user:1001"]["role"] == "owner", (
            f"user:1001 role should be 'owner', got '{state['user:1001']['role']}'"
        )
        assert state["user:1002"]["role"] == "admin", (
            f"user:1002 role should be 'admin', got '{state['user:1002']['role']}'"
        )
        assert state["metric:9001"]["value"] == 55.0, (
            f"metric:9001 value should be 55.0, got {state['metric:9001']['value']}"
        )
        assert state["order:5001"]["status"] == "pending", (
            f"order:5001 status should be 'pending', got '{state['order:5001']['status']}'"
        )

        # Report counts must match state
        assert report["state_summary"]["live_key_count"] == len(state), (
            f"Report says {report['state_summary']['live_key_count']} live keys "
            f"but state has {len(state)} keys"
        )
        assert report["state_summary"]["live_key_count"] == 12
        assert report["state_summary"]["deleted_key_count"] == 2
        assert report["compaction_summary"]["total_transactions"] == 10
        assert report["compaction_summary"]["committed_transactions"] == 8
        assert report["compaction_summary"]["aborted_transactions"] == 2
