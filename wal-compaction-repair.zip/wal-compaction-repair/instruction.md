# WAL Compaction Tool — Incident Report

## Context

We have a WAL (Write-Ahead Log) compaction tool that processes raw WAL segments from our analytics database and produces a compacted key-value state. Think PostgreSQL's WAL replay but simplified — it reads INSERT/UPDATE/DELETE operations, tracks transaction boundaries, and outputs the final materialized state after compaction.

This has been running fine for months. After a recent refactor to "improve modularity" (state_builder.py was split from a monolithic script), the compacted output stopped matching our reference snapshots.

## Symptoms

We validated against a known-good pg_dump of the same data window:

1. **Phantom keys from rolled-back transactions** — The compacted state has keys that were only ever written by ABORTed transactions. For example, `cache:7001` and `session:3003` show up in the output but the transactions that created them never committed. It's like abort rollback isn't happening.

2. **Tombstoned keys are still showing up** — Keys that were DELETEd by committed transactions still appear in the compacted state with their pre-delete values. `order:5002` was explicitly deleted but it's still there. The compaction tool is supposed to *remove* deleted keys, not keep them around.

3. **Wrong winner on multi-writer conflicts** — When two committed transactions write the same key, sometimes the wrong value wins. Specifically `user:1001` ends up with `role=superadmin` instead of `role=owner`. We traced this to a clock-skew scenario where the later transaction (by LSN) has an earlier wall-clock timestamp. The tool seems to be using timestamps for ordering instead of LSN.

4. **Compaction fingerprint doesn't match reference** — The SHA-256 fingerprint we use for CI regression detection is completely wrong. Even if we manually fix individual values, the hash doesn't match. Something about the fingerprint computation itself seems broken beyond just the data issues.

## System Architecture

The pipeline is:

```
wal_segments.log → wal_parser.py → state_builder.py → snapshot_manager.py → report_writer.py
                                                                                  ↓
                                                      compacted_state.json + compaction_report.json
```

- `compaction_engine.py` — Orchestrator. Reads WAL, runs the pipeline, writes output. This file is fine.
- `wal_parser.py` — Parses the pipe-delimited WAL format. This file is fine.
- `state_builder.py` — Replays WAL operations to build key-value state. Handles INSERT/UPDATE/DELETE application and transaction lifecycle.
- `snapshot_manager.py` — Resolves multi-writer conflicts and determines key visibility/liveness for the compacted output.
- `report_writer.py` — Writes the JSON state file and compaction report with fingerprint.

## Input Format

The WAL segment log (`wal_segments.log`) uses pipe-delimited fields:

```
LSN|TXN_ID|OPERATION|KEY|VALUE|TIMESTAMP
```

- LSN: Log Sequence Number (monotonically increasing, authoritative ordering)
- TXN_ID: Transaction identifier (e.g., txn_001)
- OPERATION: BEGIN, INSERT, UPDATE, DELETE, COMMIT, ABORT, CHECKPOINT
- KEY: affected key (e.g., "user:1001", "order:5023")
- VALUE: JSON value (empty for DELETE/BEGIN/COMMIT/ABORT)
- TIMESTAMP: wall-clock time (may have clock skew between transactions)

## Output Schema

### compacted_state.json

A JSON object mapping keys to their final values:
```json
{
  "user:1001": {"name": "alice", "role": "...", ...},
  "order:5003": {"user": "alice", "amount": 500, "status": "confirmed"},
  ...
}
```

### compaction_report.json

```json
{
  "compaction_summary": {
    "total_transactions": 10,
    "committed_transactions": 8,
    "aborted_transactions": 2,
    "total_data_operations": 32
  },
  "state_summary": {
    "live_key_count": <int>,
    "deleted_key_count": <int>,
    "keys": [<sorted list of live key names>]
  },
  "compaction_fingerprint": "<16-char hex string>"
}
```

## Environment

- Python 3.11 available system-wide
- No external dependencies needed (stdlib only)
- Output files go in `/app/runtime/`
- Run with: `python3 /app/runtime/compaction_engine.py`

## What We Need

Find and fix the bugs causing the symptoms above. The WAL data and parser are correct — the issues are in how state is built, how conflicts are resolved, and how the report is generated.

Don't add dependencies. Don't change the input format or output schema. Just make the compaction correct.
