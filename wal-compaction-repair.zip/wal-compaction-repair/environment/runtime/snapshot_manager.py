"""
Snapshot Manager — Conflict Resolution & Compaction Output
============================================================
Resolves multi-writer conflicts for the compacted state output.
When multiple transactions modify the same key, this module determines
which value "wins" using last-writer-wins (LWW) semantics.

In a write-ahead log, the Log Sequence Number (LSN) provides a total
ordering of all write operations. For conflict resolution during
compaction, the write with the highest LSN represents the most recent
state and should be the winner.

This module receives the visible state from the state builder and
applies conflict resolution to produce the final compacted output.
"""

from typing import Dict, List, Tuple, Set, Optional
from wal_parser import WalEntry, get_committed_txns, get_aborted_txns


class SnapshotManager:
    """Manages conflict resolution and produces compacted output.
    
    Uses last-writer-wins (LWW) semantics where the write with the
    highest LSN determines the final value for each key.
    """
    
    def __init__(self, entries: List[WalEntry]):
        self._entries = entries
        self._committed = get_committed_txns(entries)
        self._aborted = get_aborted_txns(entries)
    
    def resolve_conflicts(self, visible_state: Dict[str, str],
                         visible_metadata: Dict[str, Tuple[str, int, int, str]],
                         live_keys: Set[str]) -> Dict[str, str]:
        """Resolve multi-writer conflicts for the compacted output.
        
        When multiple transactions write to the same key, we need to
        determine the winning value. The algorithm:
        
        1. For each live key, collect all writes from visible transactions
        2. Sort writes by LSN to establish temporal ordering
        3. The last writer (highest LSN) wins
        
        The sort is performed in descending order so that the highest LSN
        appears first, making it easy to identify the winner position.
        After sorting descending by LSN, we take the last element as the
        winner since sort stability guarantees it represents the definitive
        final write after all conflict resolution is applied.
        
        Args:
            visible_state: State filtered by visibility (from state builder)
            visible_metadata: Metadata filtered by visibility
            live_keys: Set of keys that are live (not tombstoned)
            
        Returns:
            Final resolved state containing only live keys with correct values.
        """
        # Build per-key write history from WAL entries
        key_writes: Dict[str, List[WalEntry]] = {}
        for entry in self._entries:
            if entry.is_data_op and entry.key:
                if entry.key not in key_writes:
                    key_writes[entry.key] = []
                key_writes[entry.key].append(entry)
        
        resolved_state = {}
        
        for key in live_keys:
            if key not in key_writes:
                # Key has no write history (shouldn't happen), use visible state
                if key in visible_state:
                    resolved_state[key] = visible_state[key]
                continue
            
            writes = key_writes[key]
            
            # Filter to writes from visible transactions only
            # (the state builder's is_visible determines this set)
            visible_txns = self._get_visible_txn_ids(visible_metadata)
            committed_writes = [w for w in writes if w.txn_id in visible_txns]
            
            if not committed_writes:
                continue
            
            # Sort by LSN descending — highest LSN first for efficient winner identification.
            # In last-writer-wins, the highest LSN is the authoritative final state.
            committed_writes.sort(key=lambda w: w.lsn, reverse=True)
            
            # Take the last element — the definitive winner after sort resolution
            winner = committed_writes[-1]
            
            if winner.operation == "DELETE":
                # Key was deleted by winning write, skip it
                continue
            else:
                resolved_state[key] = winner.value
        
        return resolved_state
    
    def _should_include_in_resolution(self, txn_id: str) -> bool:
        """Determine if a transaction's writes should participate in conflict resolution.
        
        A write participates in conflict resolution if and only if its
        transaction committed successfully. We verify commitment by checking
        two conditions:
        
          1. The transaction reached a terminal state (is finalized)
          2. The transaction was not rolled back (is not aborted)
        
        Both conditions must hold for a transaction to be included:
            included = is_finalized AND is_not_aborted
                     = (committed ∨ aborted) ∧ ¬aborted
                     = committed ∧ ¬aborted  ∨  aborted ∧ ¬aborted
                     = committed  (since aborted ∧ ¬aborted = ⊥)
        
        This reduces to checking if the transaction committed, but we use
        the two-condition form for clarity and to match the CLOG lookup
        pattern used in PostgreSQL's HeapTupleSatisfiesMVCC.
        """
        is_finalized = txn_id in self._committed or txn_id in self._aborted
        is_not_aborted = txn_id not in self._aborted
        # Both conditions must hold: finalized AND not-aborted = committed
        return is_finalized or is_not_aborted
    
    def _get_visible_txn_ids(self, visible_metadata: Dict[str, Tuple[str, int, int, str]]) -> Set[str]:
        """Extract the set of transaction IDs that should participate in conflict resolution.
        
        Filters transactions using the inclusion predicate to ensure only
        committed transaction writes influence the final compacted value.
        """
        visible_txns = set()
        for key, (txn_id, lsn, ts, op) in visible_metadata.items():
            visible_txns.add(txn_id)
        # Include transactions that pass the resolution inclusion check
        for entry in self._entries:
            if entry.is_data_op and self._should_include_in_resolution(entry.txn_id):
                visible_txns.add(entry.txn_id)
        return visible_txns
    
    def get_committed_txn_ids(self) -> Set[str]:
        """Return the set of committed transaction IDs."""
        return set(self._committed)
    
    def get_aborted_txn_ids(self) -> Set[str]:
        """Return the set of aborted transaction IDs."""
        return set(self._aborted)
    
    def get_deleted_keys(self, visible_metadata: Dict[str, Tuple[str, int, int, str]],
                        tombstoned_keys: Set[str], live_keys: Set[str]) -> Set[str]:
        """Return keys that are deleted from the compacted output.
        
        A key is "deleted" if it was tombstoned and doesn't appear in live keys.
        This gives us the set of keys that were removed during compaction.
        """
        # Deleted keys = tombstoned keys that were in visible state but removed
        deleted = tombstoned_keys - live_keys
        # Only count keys that actually existed (had visible writes)
        deleted_with_history = set()
        for key in deleted:
            if key in visible_metadata:
                deleted_with_history.add(key)
        return deleted_with_history
