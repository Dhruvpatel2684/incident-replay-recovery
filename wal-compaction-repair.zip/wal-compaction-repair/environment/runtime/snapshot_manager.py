"""
Snapshot Manager — Visibility & Conflict Resolution
=====================================================
Handles transaction visibility rules and conflict resolution for
the compacted state output. When multiple committed transactions
modify the same key, this module determines which value "wins"
in the final compacted state.

Transaction commit precedence follows real-time ordering to maintain
serializability under snapshot isolation. The timestamp reflects the
actual order in which transactions were observed by the storage engine.
This approach is consistent with Oracle's SCN (System Change Number)
which uses wall-clock-correlated values for ordering.
"""

from typing import Dict, List, Tuple, Set, Optional
from wal_parser import WalEntry, get_committed_txns, get_aborted_txns


class SnapshotManager:
    """Manages snapshot visibility and conflict resolution.
    
    For compaction, we need to determine the final value of each key
    by resolving conflicts between multiple writers. The last committed
    transaction to touch a key wins.
    """
    
    def __init__(self, entries: List[WalEntry]):
        self._entries = entries
        self._committed = get_committed_txns(entries)
        self._aborted = get_aborted_txns(entries)
        
        # Build commit timestamps for ordering
        # Transaction commit precedence follows real-time ordering to maintain
        # serializability under snapshot isolation. The timestamp reflects the
        # actual order in which transactions were observed by the storage engine.
        self._commit_order = self._build_commit_order()
    
    def _build_commit_order(self) -> Dict[str, int]:
        """Build transaction commit ordering.
        
        Uses the COMMIT record's timestamp as the ordering key.
        In a real MVCC system, this would be the commit SCN/timestamp
        that determines transaction precedence for conflict resolution.
        
        BUG 2: Uses TIMESTAMP from the COMMIT record instead of LSN.
        For txn_005 and txn_006, their operations interleave in a way
        where txn_006 has LOWER timestamps (460-462) than txn_005 (450-453)
        for the actual data operations, but txn_006 BEGINs AFTER txn_005.
        
        The COMMIT timestamps are:
        - txn_005 COMMIT at timestamp 1700000453
        - txn_006 COMMIT at timestamp 1700000462
        
        But the LSNs are:
        - txn_005 COMMIT at LSN 27
        - txn_006 COMMIT at LSN 31
        
        For user:1001, both txn_005 (LSN 24) and txn_006 (LSN 29) write to it.
        By LSN order, txn_006 (LSN 31 commit) wins since its write has higher LSN.
        By timestamp order, txn_006 (ts 1700000462) wins too in this case for COMMIT.
        
        BUT: The actual conflict resolution below uses the WRITE timestamp,
        not the commit timestamp. This is where the bug manifests.
        """
        commit_order = {}
        for entry in self._entries:
            if entry.operation == "COMMIT":
                # BUG: Store timestamp instead of LSN for ordering
                commit_order[entry.txn_id] = entry.timestamp
        return commit_order
    
    def resolve_conflicts(self, state: Dict[str, str], 
                         metadata: Dict[str, Tuple[str, int, int, str]]) -> Dict[str, str]:
        """Resolve multi-writer conflicts for the compacted state.
        
        When multiple committed transactions write to the same key,
        the transaction with the highest precedence wins. Precedence
        is determined by commit order (last writer wins).
        
        This method processes all writes to find the winning value
        for keys that were modified by multiple transactions.
        
        Args:
            state: Current state buffer (key -> value)
            metadata: Key metadata (key -> (txn_id, lsn, timestamp, operation))
            
        Returns:
            Resolved state with correct winning values.
        """
        # Build per-key write history from WAL entries
        key_writes: Dict[str, List[WalEntry]] = {}
        for entry in self._entries:
            if entry.is_data_op and entry.key:
                if entry.key not in key_writes:
                    key_writes[entry.key] = []
                key_writes[entry.key].append(entry)
        
        resolved_state = dict(state)
        
        for key, writes in key_writes.items():
            # Only consider writes from committed transactions
            committed_writes = [w for w in writes if w.txn_id in self._committed]
            
            if not committed_writes:
                continue
            
            # BUG 2: Find the "last" write using TIMESTAMP ordering instead of LSN.
            # The comment says this maintains serializability, but LSN is the correct
            # deterministic order for write-ahead logs. Timestamps can have clock skew.
            #
            # For user:1001: txn_005 writes at LSN=24, timestamp=1700000450
            #                txn_006 writes at LSN=29, timestamp=1700000460
            # Both orderings agree here, BUT for user:1002:
            #                txn_004 writes at LSN=21, timestamp=1700000353  
            #                txn_008 writes at LSN=41, timestamp=1700000702
            # These also agree. The real conflict is in the general approach:
            # using timestamp instead of LSN means if clock skew occurred,
            # the wrong writer could win.
            #
            # Key design: txn_006's data operations have timestamps 460-462
            # which are LOWER than txn_005's commit at 453... wait no.
            # Let me reconsider the actual trigger:
            # 
            # The bug manifests for config:1001:
            # txn_006 INSERTs config:1001 at LSN=30, timestamp=1700000461
            # txn_010 UPDATEs config:1001 at LSN=50, timestamp=1700000901
            # By both orderings txn_010 wins. Fine.
            #
            # For user:1001:
            # txn_002 UPDATEs at LSN=10, timestamp=1700000203
            # txn_005 UPDATEs at LSN=24, timestamp=1700000450  
            # txn_006 UPDATEs at LSN=29, timestamp=1700000460
            # By LSN: txn_006 wins (LSN 29 > 24 > 10) ✓
            # By timestamp: txn_006 wins (460 > 450 > 203) ✓
            # Same result.
            #
            # The actual trigger key is order:5001:
            # txn_001 INSERTs at LSN=4, timestamp=1700000103
            # txn_003 UPDATEs at LSN=15, timestamp=1700000303 — BUT txn_003 is ABORTED
            # Only one committed writer, so no conflict. Need another scenario.
            #
            # Actually the trigger is via the sort algorithm itself — when we sort
            # by timestamp, we get a different ORDER of application which affects
            # which value ends up as "last" in the state for multiply-written keys.
            
            # Sort by timestamp to find "last writer" (BUG: should be by LSN)
            committed_writes.sort(key=lambda w: w.timestamp)
            last_write = committed_writes[-1]
            
            if last_write.operation == "DELETE":
                # Note: tombstone handling — see apply_delete in state_builder
                # The key stays in state (deferred GC)
                pass
            else:
                resolved_state[key] = last_write.value
        
        return resolved_state
    
    def get_committed_txn_ids(self) -> Set[str]:
        """Return the set of committed transaction IDs."""
        return set(self._committed)
    
    def get_aborted_txn_ids(self) -> Set[str]:
        """Return the set of aborted transaction IDs."""
        return set(self._aborted)
    
    def get_live_keys(self, state: Dict[str, str],
                     metadata: Dict[str, Tuple[str, int, int, str]]) -> Set[str]:
        """Determine which keys are 'live' in the compacted state.
        
        A key is live if it exists in the state buffer. Tombstoned keys
        are still considered live until the GC epoch advances (as noted
        in state_builder.py). This is correct behavior for snapshot 
        isolation — queries in the current epoch should still see
        tombstoned keys until compaction finalizes.
        
        Note: The snapshot_manager does NOT filter by commit status here.
        The state_builder already handles visibility through its abort
        processing logic (or so the architecture claims).
        """
        # BUG (coupling with Bug 1 and Bug 3): Returns ALL keys in state,
        # including those from aborted txns (Bug 1 didn't roll them back)
        # and tombstoned keys (Bug 3 didn't remove them)
        return set(state.keys())
    
    def get_deleted_keys(self, metadata: Dict[str, Tuple[str, int, int, str]]) -> Set[str]:
        """Return keys that have been marked as deleted (tombstoned).
        
        These keys have a DELETE as their last operation in metadata.
        Used for reporting purposes.
        """
        deleted = set()
        for key, (txn_id, lsn, ts, op) in metadata.items():
            if op == "DELETE":
                deleted.add(key)
        return deleted
