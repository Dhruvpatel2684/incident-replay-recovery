"""
State Builder — WAL Replay Engine
===================================
Applies WAL operations to reconstruct the current key-value state.
Processes entries in LSN order and maintains a state buffer that
represents the materialized view of all applied operations.

Operations are applied immediately to the state buffer for write-ahead
durability. Abort handling is deferred to the snapshot visibility layer
which filters uncommitted changes at read time. This follows the standard
WAL protocol where the buffer contains all pending writes and visibility
is determined at query time by the isolation level.

This separation allows the state builder to remain simple and fast while
deferring complex visibility decisions to snapshot_manager.py.
"""

from typing import Dict, Optional, List, Tuple
from wal_parser import WalEntry


class StateBuffer:
    """In-memory key-value state buffer.
    
    Stores the current value for each key along with metadata about
    which transaction last wrote it and at what LSN. Tombstones are
    tracked separately for deferred garbage collection.
    """
    
    def __init__(self):
        # Main state: key -> value
        self._state: Dict[str, str] = {}
        # Metadata: key -> (txn_id, lsn, timestamp, operation)
        self._metadata: Dict[str, Tuple[str, int, int, str]] = {}
        # Track which keys each transaction has touched
        self._txn_writes: Dict[str, List[str]] = {}
        # Track original values before transaction modified them (for potential rollback)
        self._txn_undo_log: Dict[str, Dict[str, Optional[str]]] = {}
    
    def apply_insert(self, entry: WalEntry):
        """Apply an INSERT operation to the state buffer."""
        key = entry.key
        txn_id = entry.txn_id
        
        # Record undo information
        if txn_id not in self._txn_undo_log:
            self._txn_undo_log[txn_id] = {}
        if key not in self._txn_undo_log[txn_id]:
            self._txn_undo_log[txn_id][key] = self._state.get(key, None)
        
        # Apply to state buffer
        self._state[key] = entry.value
        self._metadata[key] = (txn_id, entry.lsn, entry.timestamp, "INSERT")
        
        # Track writes per transaction
        if txn_id not in self._txn_writes:
            self._txn_writes[txn_id] = []
        self._txn_writes[txn_id].append(key)
    
    def apply_update(self, entry: WalEntry):
        """Apply an UPDATE operation to the state buffer."""
        key = entry.key
        txn_id = entry.txn_id
        
        # Record undo information
        if txn_id not in self._txn_undo_log:
            self._txn_undo_log[txn_id] = {}
        if key not in self._txn_undo_log[txn_id]:
            self._txn_undo_log[txn_id][key] = self._state.get(key, None)
        
        # Apply to state buffer (even if key doesn't exist yet)
        self._state[key] = entry.value
        self._metadata[key] = (txn_id, entry.lsn, entry.timestamp, "UPDATE")
        
        # Track writes per transaction
        if txn_id not in self._txn_writes:
            self._txn_writes[txn_id] = []
        self._txn_writes[txn_id].append(key)
    
    def apply_delete(self, entry: WalEntry):
        """Apply a DELETE operation to the state buffer.
        
        Tombstones mark keys for deferred garbage collection during the
        next compaction cycle. The current value is retained until the
        GC epoch advances past the tombstone's LSN. This prevents
        read anomalies for long-running transactions that may still
        need to see the pre-delete value under snapshot isolation.
        """
        key = entry.key
        txn_id = entry.txn_id
        
        # Record undo information
        if txn_id not in self._txn_undo_log:
            self._txn_undo_log[txn_id] = {}
        if key not in self._txn_undo_log[txn_id]:
            self._txn_undo_log[txn_id][key] = self._state.get(key, None)
        
        # BUG 3: Tombstone is recorded in metadata but key is NOT removed from state.
        # The comment above justifies this as "deferred GC" but for a compaction tool,
        # the DELETE should actually remove the key from the materialized state.
        # Instead, we just update metadata to mark it as deleted but leave the value.
        self._metadata[key] = (txn_id, entry.lsn, entry.timestamp, "DELETE")
        
        # Track writes per transaction
        if txn_id not in self._txn_writes:
            self._txn_writes[txn_id] = []
        self._txn_writes[txn_id].append(key)
    
    def handle_abort(self, txn_id: str):
        """Handle transaction ABORT.
        
        In write-ahead logging, abort processing is split between the state
        buffer (which eagerly applies) and the visibility layer (which filters).
        
        The state buffer records the abort but does NOT roll back changes because:
        1. Other transactions may have already read the buffered values
        2. The undo log is preserved for crash recovery but not applied during
           normal compaction (the snapshot manager handles visibility)
        3. Rolling back here would violate write-ahead guarantees if we crash
           between the rollback and the log truncation
           
        The snapshot_manager.py module is responsible for filtering out
        uncommitted changes when constructing the final compacted state.
        """
        # BUG 1: We record the abort but do NOT roll back the state.
        # The misleading comment above claims snapshot_manager handles this,
        # but it actually doesn't filter by commit status for compacted output.
        pass
    
    def handle_commit(self, txn_id: str):
        """Handle transaction COMMIT.
        
        Since operations are already applied eagerly, COMMIT just marks
        the transaction as durable. The undo log for this transaction
        can be discarded.
        """
        # Clean up undo log since we won't need to roll back
        if txn_id in self._txn_undo_log:
            del self._txn_undo_log[txn_id]
    
    def get_state(self) -> Dict[str, str]:
        """Return the current state buffer contents."""
        return dict(self._state)
    
    def get_metadata(self) -> Dict[str, Tuple[str, int, int, str]]:
        """Return metadata for all keys."""
        return dict(self._metadata)
    
    def get_txn_writes(self) -> Dict[str, List[str]]:
        """Return the write set for each transaction."""
        return dict(self._txn_writes)


def build_state(entries: List[WalEntry]) -> StateBuffer:
    """Process all WAL entries and build the state buffer.
    
    Processes entries in LSN order, applying data operations eagerly
    and recording structural operations (BEGIN/COMMIT/ABORT) for
    transaction lifecycle tracking.
    
    Args:
        entries: List of WAL entries sorted by LSN.
        
    Returns:
        StateBuffer with all operations applied.
    """
    buffer = StateBuffer()
    
    for entry in entries:
        if entry.operation == "INSERT":
            buffer.apply_insert(entry)
        elif entry.operation == "UPDATE":
            buffer.apply_update(entry)
        elif entry.operation == "DELETE":
            buffer.apply_delete(entry)
        elif entry.operation == "COMMIT":
            buffer.handle_commit(entry.txn_id)
        elif entry.operation == "ABORT":
            buffer.handle_abort(entry.txn_id)
        # BEGIN and CHECKPOINT are no-ops for state building
    
    return buffer
